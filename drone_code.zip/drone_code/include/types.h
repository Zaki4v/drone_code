#pragma once

#include <Arduino.h>

// =============================================================================
// ENUMS & SYSTEM STATES
// =============================================================================
enum FlightState : uint8_t {
    STATE_DISARMED = 0,
    STATE_CALIBRATING,
    STATE_ARMED,
    STATE_FAILSAFE,
    STATE_EMERGENCY_STOP
};

enum FlightMode : uint8_t {
    MODE_ACRO = 0,        // Direct gyro rate control
    MODE_STABILIZE = 1,   // Auto-leveling angle mode
    MODE_ALT_HOLD = 2     // Auto-leveling + Barometer Altitude Hold
};

// =============================================================================
// SENSOR DATA TYPES
// =============================================================================
struct ImuRawData {
    int16_t ax, ay, az;
    int16_t gx, gy, gz;
    int16_t temp;
};

struct ImuFilteredData {
    float ax, ay, az;     // Acceleration in g (1g = 9.80665 m/s^2)
    float gx, gy, gz;     // Angular velocity in deg/s
    float temp_c;         // IMU internal temperature in deg C
};

struct BaroData {
    float pressure_hpa;   // Atmospheric pressure in hPa
    float temperature_c;  // Barometer temperature in deg C
    float raw_altitude_m; // Raw barometric altitude above ground in meters
    float estimated_alt_m;// Kalman filtered altitude
    float vertical_vel_ms;// Kalman filtered climb rate (m/s)
    bool is_ready;
};

struct AhtData {
    float temperature_c;  // AHT20 ambient temperature
    float humidity_rh;    // AHT20 relative humidity %
    bool is_valid;
};

struct AttitudeEstimate {
    float roll;           // Degrees (-180 to +180)
    float pitch;          // Degrees (-90 to +90)
    float yaw;            // Degrees (-180 to +180)
    float q0, q1, q2, q3; // Unit Quaternion representation
};

// =============================================================================
// RADIO PROTOCOL PACKETS (Packed for byte-exact over-the-air transmission)
// =============================================================================

// Uplink Packet: Transmitter -> Drone (32 bytes max for nRF24)
struct __attribute__((packed)) RadioControlPacket {
    uint16_t throttle;    // 1000 - 2000 us
    int16_t  roll;        // 1000 - 2000 us (Center: 1500)
    int16_t  pitch;       // 1000 - 2000 us (Center: 1500)
    int16_t  yaw;         // 1000 - 2000 us (Center: 1500)
    uint8_t  aux1;        // Arm Switch (0: Disarm, 1: Arm)
    uint8_t  aux2;        // Flight Mode (0: Acro, 1: Stabilize, 2: AltHold)
    uint8_t  aux3;        // Buzzer / Extra switch (0/1)
    uint8_t  aux4;        // Emergency Kill switch (0/1)
    uint16_t packet_seq;  // Packet sequence counter
    uint16_t checksum;    // CRC16 verification
};

// Downlink Packet: Drone -> Transmitter (Telemetry back)
struct __attribute__((packed)) RadioTelemetryPacket {
    int16_t  roll_deg_x10;      // Roll * 10
    int16_t  pitch_deg_x10;     // Pitch * 10
    int16_t  yaw_deg_x10;       // Yaw * 10
    int16_t  altitude_cm;       // Altitude in cm
    int16_t  vspeed_cms;        // Vertical speed in cm/s
    uint16_t vbat_mv;           // Battery voltage in millivolts (e.g. 11400 for 11.4V)
    int16_t  temp_aht_x10;      // Ambient temp * 10
    uint16_t humidity_x10;      // Relative humidity * 10
    uint8_t  flight_state;      // FlightState enum
    uint8_t  flight_mode;       // FlightMode enum
    uint8_t  rssi_quality;      // Link quality (0-100%)
    uint8_t  checksum;          // Simple XOR checksum
};

// =============================================================================
// PID & MOTOR STRUCTS
// =============================================================================
struct PidGains {
    float kp;
    float ki;
    float kd;
    float i_max;
};

struct PidController {
    PidGains gains;
    float target;
    float current;
    float prev_error;
    float integral;
    float derivative;
    float output;
    float d_filter_alpha;
};

struct MotorOutputs {
    uint16_t m1; // Front-Right (CCW)
    uint16_t m2; // Rear-Right  (CW)
    uint16_t m3; // Rear-Left   (CCW)
    uint16_t m4; // Front-Left  (CW)
};
