#pragma once

#include <Arduino.h>
#include <SPI.h>
#include <RF24.h>
#include "types.h"
#include "config.h"

class RadioDriver {
public:
    RadioDriver();
    bool init();

    // Check for incoming control packets
    bool receiveControl(RadioControlPacket &ctrl);

    // Send telemetry downlink packet back to transmitter
    bool sendTelemetry(const RadioTelemetryPacket &telem);

    // Failsafe status
    bool isFailsafeActive() const { return failsafe_active; }
    uint32_t getLastPacketAgeMs() const { return millis() - last_packet_time_ms; }
    uint8_t getLinkQuality() const { return link_quality_pct; }

    void updateLinkStats();

private:
    RF24 radio;
    SPIClass spi_bus;

    uint32_t last_packet_time_ms;
    bool     failsafe_active;
    uint32_t packets_received_window;
    uint32_t last_stats_calc_time_ms;
    uint8_t  link_quality_pct;
    uint16_t last_seq_num;

    uint16_t calculateCrc16(const uint8_t *data, size_t len);
};
