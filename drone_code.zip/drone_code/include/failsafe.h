#pragma once

#include <Arduino.h>
#include "types.h"
#include "config.h"

class FailsafeManager {
public:
    FailsafeManager();
    void init();

    // Check arming conditions and transitions
    void update(const RadioControlPacket &rc_cmd,
                const AttitudeEstimate &attitude,
                bool radio_failsafe,
                FlightState &current_state,
                FlightMode  &current_mode);

    // Battery monitoring
    void updateBattery();
    float getBatteryVoltage() const { return battery_voltage; }
    uint16_t getBatteryVoltageMv() const { return (uint16_t)(battery_voltage * 1000.0f); }
    bool isBatteryCritical() const { return battery_critical; }
    bool isBatteryWarning() const { return battery_warning; }

    // Buzzer and LED notification routines
    void updateIndicators(FlightState state, FlightMode mode);
    void beep(uint16_t freq_hz, uint16_t duration_ms);

private:
    float battery_voltage;
    bool  battery_warning;
    bool  battery_critical;

    uint32_t arm_gesture_timer;
    uint32_t disarm_gesture_timer;
    uint32_t buzzer_timer;
    uint32_t led_timer;
    bool     led_state;
};
