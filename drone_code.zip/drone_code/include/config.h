#pragma once

#include <Arduino.h>

// =============================================================================
// HARDWARE PIN ASSIGNMENTS (ESP32-S3 Optimized)
// =============================================================================

// --- I2C Bus Pins (MPU6050 + BMP280 + AHT20) ---
#define PIN_I2C_SDA             8
#define PIN_I2C_SCL             9
#define I2C_CLOCK_SPEED         400000    // 400kHz Fast I2C

// --- SPI Bus Pins (nRF24L01+ PA/LNA) ---
#define PIN_SPI_SCK             12
#define PIN_SPI_MISO            13
#define PIN_SPI_MOSI            11
#define PIN_NRF_CE              10
#define PIN_NRF_CSN             14
#define PIN_NRF_IRQ             21

// --- Motor ESC PWM Output Pins (Quad-X Layout) ---
// Motor 1: Front-Right (Counter-Clockwise - CCW)
// Motor 2: Rear-Right  (Clockwise - CW)
// Motor 3: Rear-Left   (Counter-Clockwise - CCW)
// Motor 4: Front-Left  (Clockwise - CW)
#define PIN_MOTOR_1             15
#define PIN_MOTOR_2             16
#define PIN_MOTOR_3             17
#define PIN_MOTOR_4             18

// --- Peripherals & Telemetry ---
#define PIN_BATTERY_VOLTAGE     1         // ADC1_CH0 with 10:1 resistor divider
#define PIN_BUZZER              6         // Piezo buzzer
#define PIN_STATUS_LED          7         // External Status LED (or 48 for onboard WS2812)

// =============================================================================
// RADIO & COMMUNICATIONS CONFIGURATION (nRF24L01+ PA+LNA)
// =============================================================================
#define NRF_CHANNEL             108       // 2.508 GHz (Avoids standard 2.4GHz WiFi overlap)
#define NRF_DATA_RATE           RF24_250KBPS // 250kbps for maximum range & penetration
#define NRF_PA_LEVEL            RF24_PA_MAX  // Max power amplifier level
#define NRF_PIPE_TX             0xE8E8F0F0E1LL
#define NRF_PIPE_RX             0xE8E8F0F0D2LL
#define RADIO_TIMEOUT_MS        500       // Trigger Failsafe if no signal for 500ms
#define TELEMETRY_INTERVAL_MS   50        // 20Hz Telemetry downlink rate

// =============================================================================
// FLIGHT CONTROLLER TIMING & TASKS (FreeRTOS)
// =============================================================================
#define FLIGHT_LOOP_FREQ_HZ     500       // 500Hz Primary Flight Control Loop (2.0 ms)
#define FLIGHT_LOOP_DT          (1.0f / FLIGHT_LOOP_FREQ_HZ)
#define COMMS_TASK_FREQ_HZ      100       // 100Hz Radio / Navigation Loop (10.0 ms)
#define BARO_UPDATE_FREQ_HZ     50        // 50Hz Altitude estimation (20.0 ms)
#define AHT20_UPDATE_FREQ_HZ    1         // 1Hz Environmental update

// =============================================================================
// ESC & MOTOR TIMING CONFIGURATION (40A ESC + A2212 1400KV)
// =============================================================================
#define ESC_PWM_FREQ_HZ         400       // 400Hz High-speed standard PWM (or 50Hz for legacy ESC)
#define MOTOR_PULSE_MIN         1000      // Microseconds (Full Stop / Idle)
#define MOTOR_PULSE_MAX         2000      // Microseconds (Full Throttle)
#define MOTOR_PULSE_ARM_IDLE    1120      // Spin-on-arm minimum throttle (prevents motor stall)
#define MOTOR_PULSE_CALIB_HIGH  2000      // For ESC Throttle Range Calibration
#define MOTOR_PULSE_CALIB_LOW   1000

// =============================================================================
// SAFETY & FAILSAFE THRESHOLDS
// =============================================================================
#define MAX_ALLOWED_ANGLE_DEG   55.0f     // Emergency cut-off if drone tilts > 55 deg
#define FAILSAFE_DESCENT_RATE   15        // Pulse decrement step during failsafe soft-landing
#define BATTERY_VOLTAGE_MIN_3S  10.2f     // 3.4V per cell for 3S LiPo (Critical Alarm)
#define BATTERY_VOLTAGE_WARN_3S 10.8f     // 3.6V per cell for 3S LiPo (Warning Alarm)
#define ADC_VOLTAGE_DIVIDER_RATIO 11.0f   // (R1 + R2) / R2 -> (100k + 10k) / 10k = 11.0
#define ADC_VREF                3.3f
#define ADC_RESOLUTION          4095.0f

// =============================================================================
// SENSOR CALIBRATION DEFAULTS
// =============================================================================
#define MPU6050_CALIB_SAMPLES   1000      // Number of samples for gyro zero-bias calibration
#define MAHONY_TWO_KP_DEF       (2.0f * 0.8f) // 2 * Proportional gain for Mahony AHRS
#define MAHONY_TWO_KI_DEF       (2.0f * 0.01f)// 2 * Integral gain for Mahony AHRS

// =============================================================================
// PID DEFAULT TUNING PARAMETERS (Optimized for A2212 1400KV / 3S / 450mm Frame)
// =============================================================================
// Outer Loop (Angle / Attitude Controller -> outputs desired deg/s)
#define PID_ROLL_ANGLE_KP       4.5f
#define PID_ROLL_ANGLE_KI       0.0f
#define PID_ROLL_ANGLE_KD       0.0f
#define PID_ROLL_ANGLE_LIMIT    180.0f    // Max target rate in deg/s

#define PID_PITCH_ANGLE_KP      4.5f
#define PID_PITCH_ANGLE_KI      0.0f
#define PID_PITCH_ANGLE_KD      0.0f
#define PID_PITCH_ANGLE_LIMIT   180.0f

// Inner Loop (Rate Controller -> outputs motor command adjustments)
#define PID_ROLL_RATE_KP        1.25f
#define PID_ROLL_RATE_KI        1.80f
#define PID_ROLL_RATE_KD        0.038f
#define PID_ROLL_RATE_I_MAX     250.0f

#define PID_PITCH_RATE_KP       1.25f
#define PID_PITCH_RATE_KI       1.80f
#define PID_PITCH_RATE_KD       0.038f
#define PID_PITCH_RATE_I_MAX    250.0f

#define PID_YAW_RATE_KP         2.80f
#define PID_YAW_RATE_KI         2.10f
#define PID_YAW_RATE_KD         0.005f
#define PID_YAW_RATE_I_MAX      200.0f

// Altitude Hold PID (BMP280 Baro fused)
#define PID_ALT_KP              1.8f
#define PID_ALT_KI              0.6f
#define PID_ALT_KD              0.9f
#define PID_ALT_I_MAX           150.0f
