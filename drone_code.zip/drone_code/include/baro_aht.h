#pragma once

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_AHTX0.h>
#include "types.h"
#include "config.h"

// 1D Kalman Filter for Altitude and Vertical Velocity estimation
class AltitudeKalmanFilter {
public:
    AltitudeKalmanFilter();
    void reset(float initial_alt = 0.0f);
    void predict(float vertical_accel_ms2, float dt);
    void update(float measured_baro_alt_m);

    float getAltitude() const { return z; }
    float getVelocity() const { return vz; }

private:
    float z;   // Position (Altitude in meters)
    float vz;  // Velocity (Vertical velocity in m/s)

    // Covariance matrix P = [P00 P01; P10 P11]
    float P00, P01, P10, P11;

    // Process & Measurement Noise
    float Q_accel; // Process noise from accelerometer
    float R_baro;  // Measurement noise from barometer
};

class BaroAhtDriver {
public:
    BaroAhtDriver();
    bool init();
    void updateBaro(float vertical_accel_ms2, float dt);
    void updateAht();
    void calibrateGroundLevel();

    BaroData getBaroData() const { return baro_data; }
    AhtData  getAhtData() const  { return aht_data; }

    float getAltitude() const { return baro_data.estimated_alt_m; }
    float getClimbRate() const { return baro_data.vertical_vel_ms; }

private:
    Adafruit_BMP280 bmp;
    Adafruit_AHTX0  aht;
    AltitudeKalmanFilter kalman;

    BaroData baro_data;
    AhtData  aht_data;

    float sea_level_ref_hpa;
    float ground_altitude_offset_m;
    bool  bmp_online;
    bool  aht_online;
};
