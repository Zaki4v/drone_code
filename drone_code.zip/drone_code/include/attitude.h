#pragma once

#include <Arduino.h>
#include "types.h"
#include "config.h"

class MahonyAHRS {
public:
    MahonyAHRS(float two_kp = MAHONY_TWO_KP_DEF, float two_ki = MAHONY_TWO_KI_DEF);

    void reset();
    void setGains(float two_kp, float two_ki);

    // Update 6-DOF attitude estimate
    // gx, gy, gz in rad/s or deg/s
    // ax, ay, az in g or m/s^2 (will be normalized)
    // dt in seconds
    void update(float gx_degs, float gy_degs, float gz_degs,
                float ax, float ay, float az,
                float dt, AttitudeEstimate &estimate);

    float getRoll() const  { return roll_deg; }
    float getPitch() const { return pitch_deg; }
    float getYaw() const   { return yaw_deg; }

    void getQuaternion(float &q0_out, float &q1_out, float &q2_out, float &q3_out) const {
        q0_out = q0; q1_out = q1; q2_out = q2; q3_out = q3;
    }

private:
    float twoKp; // 2 * proportional gain (Kp)
    float twoKi; // 2 * integral gain (Ki)
    float q0, q1, q2, q3; // Quaternion of sensor frame relative to earth frame
    float integralFBx, integralFBy, integralFBz; // Integral error terms scaled by Ki

    float roll_deg;
    float pitch_deg;
    float yaw_deg;

    static float invSqrt(float x);
};
