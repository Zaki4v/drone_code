#pragma once

#include <Arduino.h>
#include "types.h"
#include "config.h"

class PIDAxis {
public:
    PIDAxis();
    void init(float kp, float ki, float kd, float i_max, float d_cutoff_hz = 30.0f, float loop_rate_hz = FLIGHT_LOOP_FREQ_HZ);
    void reset();
    void setGains(float kp, float ki, float kd, float i_max);

    // Standard PID calculation (Derivative on Measurement to eliminate setpoint kick)
    float update(float target, float current, float dt);

    // Rate update using gyro measurement directly for D-term
    float updateRate(float target_rate, float current_gyro_rate, float dt);

    float getP() const { return p_term; }
    float getI() const { return i_term; }
    float getD() const { return d_term; }
    float getOutput() const { return last_output; }

private:
    float kp, ki, kd, i_max;
    float integral;
    float prev_measurement;
    float prev_error;
    float d_filter_alpha;
    float d_term_filtered;

    float p_term;
    float i_term;
    float d_term;
    float last_output;
};

class FlightPIDController {
public:
    FlightPIDController();
    void init();
    void reset();

    // Cascaded Attitude + Rate update for Roll & Pitch, and direct Rate update for Yaw
    void update(FlightMode mode,
                float target_roll_deg, float target_pitch_deg, float target_yaw_rate_degs,
                const AttitudeEstimate &attitude,
                const ImuFilteredData &imu,
                float dt,
                float &roll_out, float &pitch_out, float &yaw_out);

    // Altitude Hold PID update (returns throttle compensation in pulse microseconds)
    float updateAltitude(float target_alt_m, float current_alt_m, float vertical_vel_ms, float dt);

    // Tuning API
    void setAngleGains(float roll_kp, float pitch_kp);
    void setRateGains(float r_kp, float r_ki, float r_kd,
                      float p_kp, float p_ki, float p_kd,
                      float y_kp, float y_ki, float y_kd);

private:
    // Outer loop: Angle controllers
    PIDAxis roll_angle_pid;
    PIDAxis pitch_angle_pid;

    // Inner loop: Rate controllers
    PIDAxis roll_rate_pid;
    PIDAxis pitch_rate_pid;
    PIDAxis yaw_rate_pid;

    // Altitude controller
    PIDAxis alt_pid;
};
