#pragma once

#include <Arduino.h>
#include <Wire.h>
#include "types.h"
#include "config.h"

// MPU6050 I2C Address
#define MPU6050_I2C_ADDR        0x68

// MPU6050 Registers
#define MPU_REG_SMPLRT_DIV      0x19
#define MPU_REG_CONFIG          0x1A
#define MPU_REG_GYRO_CONFIG     0x1B
#define MPU_REG_ACCEL_CONFIG    0x1C
#define MPU_REG_FIFO_EN         0x23
#define MPU_REG_INT_PIN_CFG     0x37
#define MPU_REG_INT_ENABLE      0x38
#define MPU_REG_ACCEL_XOUT_H    0x3B
#define MPU_REG_TEMP_OUT_H      0x41
#define MPU_REG_GYRO_XOUT_H     0x43
#define MPU_REG_USER_CTRL       0x6A
#define MPU_REG_PWR_MGMT_1      0x6B
#define MPU_REG_PWR_MGMT_2      0x6C
#define MPU_REG_WHO_AM_I        0x75

// Scale factors
// ±8g: 4096 LSB/g -> 1 / 4096 = 0.00024414f g/LSB
#define ACCEL_SCALE_FACTOR      (1.0f / 4096.0f)
// ±2000 deg/s: 16.4 LSB/(deg/s) -> 1 / 16.4 = 0.061035f deg/s/LSB
#define GYRO_SCALE_FACTOR       (1.0f / 16.4f)

class IMUDriver {
public:
    IMUDriver();
    bool init(uint8_t sda_pin = PIN_I2C_SDA, uint8_t scl_pin = PIN_I2C_SCL, uint32_t frequency = I2C_CLOCK_SPEED);
    bool readRaw(ImuRawData &raw);
    void readFiltered(ImuFilteredData &filtered);
    void calibrateGyro(uint16_t sample_count = MPU6050_CALIB_SAMPLES);
    bool loadCalibration();
    void saveCalibration();

    // Bias accessors
    float getGyroBiasX() const { return gyro_bias_x; }
    float getGyroBiasY() const { return gyro_bias_y; }
    float getGyroBiasZ() const { return gyro_bias_z; }

    // Low-pass filter cutoffs
    void setFilterCutoff(float gyro_lpf_hz, float accel_lpf_hz, float loop_rate_hz);

private:
    float gyro_bias_x, gyro_bias_y, gyro_bias_z;
    float accel_bias_x, accel_bias_y, accel_bias_z;

    // 1st order Low-Pass Filter state
    float lpf_alpha_gyro;
    float lpf_alpha_accel;
    ImuFilteredData prev_filtered;

    bool writeRegister(uint8_t reg, uint8_t data);
    uint8_t readRegister(uint8_t reg);
    bool readBytes(uint8_t reg, uint8_t *buffer, uint8_t length);
};
