#pragma once

#include <Arduino.h>
#include "types.h"
#include "config.h"

class MotorDriver {
public:
    MotorDriver();
    void init();
    void arm();
    void disarm();
    bool isArmed() const { return armed; }

    // Mixes Throttle, Roll, Pitch, Yaw outputs and writes to hardware PWM timers
    void mixAndWrite(uint16_t base_throttle, float roll_cmd, float pitch_cmd, float yaw_cmd);

    // Direct pulse write (for ESC calibration or test)
    void writeMicroseconds(uint8_t motor_idx, uint16_t us);
    void writeAll(uint16_t us);

    // Get current outputs in microseconds
    MotorOutputs getOutputs() const { return current_outputs; }

    // ESC Throttle range calibration sequence
    void runCalibrationSequence();

private:
    bool armed;
    MotorOutputs current_outputs;

    uint32_t usToDuty(uint16_t us);
};
