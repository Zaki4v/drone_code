# ESP32-S3 Professional Quadcopter Flight Controller
## Professional-grade drone firmware for ESP32-S3 with full sensor fusion, cascaded PID control, and failsafe management.

---

## Hardware Platform
| Component | Specification |
|---|---|
| MCU | ESP32-S3 (Dual-Core 240MHz Xtensa LX7) |
| Motors | 4x A2212 1400KV Brushless Outrunner |
| ESCs | 4x 40A Brushless ESC (400Hz PWM) |
| Radio | nRF24L01+ PA+LNA (Amplified, SMA Antenna) |
| IMU | MPU6050 6-DOF (I2C @ 400kHz) |
| Barometer | BMP280 High-Precision (I2C) |
| Temp/Humidity | AHT20 (I2C) |
| Battery | 3S LiPo (11.1V) |

## Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    ESP32-S3 DUAL CORE                       │
│                                                             │
│  ┌─ CORE 1 (500Hz) ─────────────────────────────────────┐   │
│  │  FlightLoopTask:                                      │   │
│  │  MPU6050 Read → Mahony AHRS → Cascaded PID → Motor Mix│   │
│  └───────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─ CORE 0 (100Hz) ─────────────────────────────────────┐   │
│  │  NavCommsTask:                                        │   │
│  │  nRF24 Radio RX → Failsafe → BMP280 Kalman → Telem TX│   │
│  └───────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## Key Features
- **500Hz Real-Time Flight Loop** on Core 1 with `vTaskDelayUntil` deterministic timing
- **Mahony AHRS** quaternion-based attitude estimation (gyro + accelerometer fusion)
- **Cascaded Dual-Loop PID**: Outer Angle Controller → Inner Rate Controller for Roll/Pitch/Yaw
- **1D Kalman Filter** altitude estimation fusing BMP280 barometer + IMU vertical acceleration
- **nRF24L01+ PA/LNA** long-range 250kbps radio with CRC16 integrity checks and ACK-payload telemetry
- **Comprehensive Failsafe**: Radio loss auto-descent, tilt-angle crash detection, battery voltage monitoring, emergency kill switch
- **ESC Throttle Calibration** mode triggered via BOOT button
- **NVS Flash Calibration Storage** for gyro/accel bias values (survives power cycles)

## Project Structure
```
drone_code/
├── platformio.ini              # PlatformIO build configuration
├── include/
│   ├── config.h                # All hardware pins, timing, PID gains
│   ├── types.h                 # Structs, enums, packet definitions
│   ├── imu.h                   # MPU6050 driver header
│   ├── attitude.h              # Mahony AHRS filter header
│   ├── pid.h                   # Cascaded PID controller header
│   ├── motors.h                # ESC PWM motor driver header
│   ├── radio.h                 # nRF24L01+ radio driver header
│   └── failsafe.h              # Safety, arming, battery monitor header
├── src/
│   ├── main.cpp                # FreeRTOS entry point & task orchestration
│   ├── imu.cpp                 # MPU6050 I2C driver + calibration + LPF
│   ├── attitude.cpp            # Mahony AHRS quaternion filter
│   ├── pid.cpp                 # Cascaded PID + Altitude Hold controller
│   ├── motors.cpp              # LEDC PWM motor mixing (Quad-X)
│   ├── radio.cpp               # nRF24L01+ SPI radio driver
│   ├── baro_aht.cpp            # BMP280 + AHT20 + Kalman altitude filter
│   └── failsafe.cpp            # Arming logic, battery, buzzer, LED
├── transmitter/
│   ├── transmitter_config.h    # Transmitter pin & radio configuration
│   └── transmitter.ino         # Arduino TX firmware (50Hz, joystick, display)
├── schematics/
│   ├── WIRING_DIAGRAM.md       # Complete wiring & pin map
│   └── PID_TUNING_GUIDE.md     # Calibration & tuning procedures
└── README.md                   # This file
```

## Quick Start

### 1. Install PlatformIO
```bash
pip install platformio
```

### 2. Build & Flash Drone Firmware
```bash
cd drone_code
pio run -t upload
```

### 3. Build Transmitter (Arduino IDE)
Open `transmitter/transmitter.ino` in Arduino IDE, select your ESP32 board, and upload.

### 4. Calibrate ESCs
Hold BOOT button (GPIO 0) while powering on → Follow serial monitor instructions.

### 5. Fly
- Power on transmitter first.
- Power on drone (wait for 3 beep confirmation).
- Move throttle to minimum.
- Flip ARM switch (or throttle-low + yaw-right for 0.5s).
- Gently increase throttle to hover.

---

## Safety Warnings
⚠️ **ALWAYS REMOVE PROPELLERS** when testing firmware, calibrating ESCs, or tuning PIDs on the bench.
⚠️ **NEVER arm the drone while holding it in your hand.**
⚠️ Test outdoors in open space, away from people. A 1400KV motor with 8-inch prop generates enough force to cause serious injury.
⚠️ Keep a spotter with the kill switch (AUX4) during first flights.
