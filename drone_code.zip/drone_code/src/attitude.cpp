#include "attitude.h"
#include <math.h>

#define DEG_TO_RAD_F    (0.017453292519943295f)
#define RAD_TO_DEG_F    (57.29577951308232f)

MahonyAHRS::MahonyAHRS(float two_kp, float two_ki)
    : twoKp(two_kp), twoKi(two_ki),
      q0(1.0f), q1(0.0f), q2(0.0f), q3(0.0f),
      integralFBx(0.0f), integralFBy(0.0f), integralFBz(0.0f),
      roll_deg(0.0f), pitch_deg(0.0f), yaw_deg(0.0f) {
}

void MahonyAHRS::reset() {
    q0 = 1.0f;
    q1 = 0.0f;
    q2 = 0.0f;
    q3 = 0.0f;
    integralFBx = 0.0f;
    integralFBy = 0.0f;
    integralFBz = 0.0f;
    roll_deg = 0.0f;
    pitch_deg = 0.0f;
    yaw_deg = 0.0f;
}

void MahonyAHRS::setGains(float two_kp, float two_ki) {
    twoKp = two_kp;
    twoKi = two_ki;
}

float MahonyAHRS::invSqrt(float x) {
    if (x <= 0.0f) return 0.0f;
    return 1.0f / sqrtf(x);
}

void MahonyAHRS::update(float gx_degs, float gy_degs, float gz_degs,
                        float ax, float ay, float az,
                        float dt, AttitudeEstimate &estimate) {
    // Convert gyro from deg/s to rad/s
    float gx = gx_degs * DEG_TO_RAD_F;
    float gy = gy_degs * DEG_TO_RAD_F;
    float gz = gz_degs * DEG_TO_RAD_F;

    float recipNorm;
    float halfvx, halfvy, halfvz;
    float halfex, halfey, halfez;
    float qa, qb, qc;

    // Compute feedback only if accelerometer measurement is valid (avoids NaN)
    if (!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f))) {
        // Normalize accelerometer measurement
        recipNorm = invSqrt(ax * ax + ay * ay + az * az);
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;

        // Estimated direction of gravity in body frame
        halfvx = q1 * q3 - q0 * q2;
        halfvy = q0 * q1 + q2 * q3;
        halfvz = q0 * q0 - 0.5f + q3 * q3;

        // Error is cross product between estimated direction and measured direction of gravity
        halfex = (ay * halfvz - az * halfvy);
        halfey = (az * halfvx - ax * halfvz);
        halfez = (ax * halfvy - ay * halfvx);

        // Compute and apply integral feedback if enabled
        if (twoKi > 0.0f) {
            integralFBx += twoKi * halfex * dt;
            integralFBy += twoKi * halfey * dt;
            integralFBz += twoKi * halfez * dt;
            gx += integralFBx;
            gy += integralFBy;
            gz += integralFBz;
        } else {
            integralFBx = 0.0f;
            integralFBy = 0.0f;
            integralFBz = 0.0f;
        }

        // Apply proportional feedback
        gx += twoKp * halfex;
        gy += twoKp * halfey;
        gz += twoKp * halfez;
    }

    // Integrate rate of change of quaternion
    gx *= (0.5f * dt);
    gy *= (0.5f * dt);
    gz *= (0.5f * dt);
    qa = q0;
    qb = q1;
    qc = q2;
    q0 += (-qb * gx - qc * gy - q3 * gz);
    q1 += (qa * gx + qc * gz - q3 * gy);
    q2 += (qa * gy - qb * gz + q3 * gx);
    q3 += (qa * gz + qb * gy - qc * gx);

    // Normalize quaternion
    recipNorm = invSqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);
    q0 *= recipNorm;
    q1 *= recipNorm;
    q2 *= recipNorm;
    q3 *= recipNorm;

    // Convert to Euler angles (Roll, Pitch, Yaw in Degrees)
    // Roll: rotation around X axis
    float sinr_cosp = 2.0f * (q0 * q1 + q2 * q3);
    float cosr_cosp = 1.0f - 2.0f * (q1 * q1 + q2 * q2);
    roll_deg = atan2f(sinr_cosp, cosr_cosp) * RAD_TO_DEG_F;

    // Pitch: rotation around Y axis
    float sinp = 2.0f * (q0 * q2 - q3 * q1);
    if (fabsf(sinp) >= 1.0f)
        pitch_deg = copysignf(90.0f, sinp); // Use 90 degrees if out of range
    else
        pitch_deg = asinf(sinp) * RAD_TO_DEG_F;

    // Yaw: rotation around Z axis
    float siny_cosp = 2.0f * (q0 * q3 + q1 * q2);
    float cosy_cosp = 1.0f - 2.0f * (q2 * q2 + q3 * q3);
    yaw_deg = atan2f(siny_cosp, cosy_cosp) * RAD_TO_DEG_F;

    // Populate estimate output
    estimate.roll  = roll_deg;
    estimate.pitch = pitch_deg;
    estimate.yaw   = yaw_deg;
    estimate.q0    = q0;
    estimate.q1    = q1;
    estimate.q2    = q2;
    estimate.q3    = q3;
}
