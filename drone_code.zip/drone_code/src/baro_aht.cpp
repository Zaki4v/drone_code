#include "baro_aht.h"

// =============================================================================
// Altitude Kalman Filter Implementation
// =============================================================================
AltitudeKalmanFilter::AltitudeKalmanFilter()
    : z(0.0f), vz(0.0f),
      P00(1.0f), P01(0.0f), P10(0.0f), P11(1.0f),
      Q_accel(0.05f), R_baro(0.60f) {
}

void AltitudeKalmanFilter::reset(float initial_alt) {
    z = initial_alt;
    vz = 0.0f;
    P00 = 1.0f;
    P01 = 0.0f;
    P10 = 0.0f;
    P11 = 1.0f;
}

void AltitudeKalmanFilter::predict(float vertical_accel_ms2, float dt) {
    // State Prediction: x = F*x + B*u
    z += vz * dt + 0.5f * vertical_accel_ms2 * dt * dt;
    vz += vertical_accel_ms2 * dt;

    // Covariance Prediction: P = F*P*F' + Q
    float dt2 = dt * dt;
    float dt3 = dt2 * dt;
    float dt4 = dt2 * dt2;

    float q_pos = Q_accel * 0.25f * dt4;
    float q_vel = Q_accel * dt2;
    float q_pos_vel = Q_accel * 0.5f * dt3;

    float P00_new = P00 + (P01 + P10) * dt + P11 * dt2 + q_pos;
    float P01_new = P01 + P11 * dt + q_pos_vel;
    float P10_new = P10 + P11 * dt + q_pos_vel;
    float P11_new = P11 + q_vel;

    P00 = P00_new;
    P01 = P01_new;
    P10 = P10_new;
    P11 = P11_new;
}

void AltitudeKalmanFilter::update(float measured_baro_alt_m) {
    // Measurement residual
    float y = measured_baro_alt_m - z;

    // Innovation covariance: S = H*P*H' + R
    float S = P00 + R_baro;
    if (fabsf(S) < 0.0001f) return;

    // Kalman gain: K = P*H' / S
    float K0 = P00 / S;
    float K1 = P10 / S;

    // State update: x = x + K*y
    z += K0 * y;
    vz += K1 * y;

    // Covariance update: P = (I - K*H)*P
    float P00_temp = P00 - K0 * P00;
    float P01_temp = P01 - K0 * P01;
    float P10_temp = P10 - K1 * P00;
    float P11_temp = P11 - K1 * P01;

    P00 = P00_temp;
    P01 = P01_temp;
    P10 = P10_temp;
    P11 = P11_temp;
}

// =============================================================================
// BaroAhtDriver Implementation
// =============================================================================
BaroAhtDriver::BaroAhtDriver()
    : sea_level_ref_hpa(1013.25f), ground_altitude_offset_m(0.0f),
      bmp_online(false), aht_online(false) {
    memset(&baro_data, 0, sizeof(BaroData));
    memset(&aht_data, 0, sizeof(AhtData));
}

bool BaroAhtDriver::init() {
    // Try BMP280 at 0x76 then 0x77
    if (bmp.begin(0x76)) {
        bmp_online = true;
        Serial.println("[BARO] BMP280 detected at I2C address 0x76.");
    } else if (bmp.begin(0x77)) {
        bmp_online = true;
        Serial.println("[BARO] BMP280 detected at I2C address 0x77.");
    } else {
        Serial.println("[BARO] WARNING: BMP280 Barometer not found on I2C bus!");
        bmp_online = false;
    }

    if (bmp_online) {
        // High precision sampling for drone altitude hold
        bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,     // Operating Mode
                        Adafruit_BMP280::SAMPLING_X2,     // Temp. oversampling
                        Adafruit_BMP280::SAMPLING_X16,    // Pressure oversampling
                        Adafruit_BMP280::FILTER_X16,      // IIR Filtering
                        Adafruit_BMP280::STANDBY_MS_1);   // Standby time 1ms -> ~60Hz output
    }

    // Initialize AHT20
    if (aht.begin()) {
        aht_online = true;
        Serial.println("[AHT20] AHT20 Temperature/Humidity sensor initialized at 0x38.");
    } else {
        Serial.println("[AHT20] WARNING: AHT20 sensor not found on I2C bus!");
        aht_online = false;
    }

    if (bmp_online) {
        calibrateGroundLevel();
    }

    return (bmp_online || aht_online);
}

void BaroAhtDriver::calibrateGroundLevel() {
    if (!bmp_online) return;

    Serial.println("[BARO] Calibrating ground reference altitude (100 samples)...");
    double sum_alt = 0.0;
    int samples = 0;

    for (int i = 0; i < 100; i++) {
        float p = bmp.readPressure() / 100.0f; // in hPa
        if (p > 300.0f && p < 1200.0f) {
            float alt = 44330.0f * (1.0f - powf(p / sea_level_ref_hpa, 0.1903f));
            sum_alt += alt;
            samples++;
        }
        delay(10);
    }

    if (samples > 0) {
        ground_altitude_offset_m = (float)(sum_alt / samples);
        kalman.reset(0.0f);
        Serial.printf("[BARO] Ground Altitude Offset set to: %.2f m\n", ground_altitude_offset_m);
    }
}

void BaroAhtDriver::updateBaro(float vertical_accel_ms2, float dt) {
    if (!bmp_online) return;

    float pressure = bmp.readPressure() / 100.0f; // hPa
    float temp = bmp.readTemperature();           // deg C

    if (pressure > 300.0f && pressure < 1200.0f) {
        float abs_alt = 44330.0f * (1.0f - powf(pressure / sea_level_ref_hpa, 0.1903f));
        float rel_alt = abs_alt - ground_altitude_offset_m;

        // Kalman prediction step using IMU vertical acceleration
        kalman.predict(vertical_accel_ms2, dt);

        // Kalman measurement update step using Baro
        kalman.update(rel_alt);

        baro_data.pressure_hpa    = pressure;
        baro_data.temperature_c   = temp;
        baro_data.raw_altitude_m  = rel_alt;
        baro_data.estimated_alt_m = kalman.getAltitude();
        baro_data.vertical_vel_ms = kalman.getVelocity();
        baro_data.is_ready        = true;
    }
}

void BaroAhtDriver::updateAht() {
    if (!aht_online) return;

    sensors_event_t humidity, temp;
    if (aht.getEvent(&humidity, &temp)) {
        aht_data.temperature_c = temp.temperature;
        aht_data.humidity_rh   = humidity.relative_humidity;
        aht_data.is_valid      = true;
    }
}
