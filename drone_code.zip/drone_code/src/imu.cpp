#include "imu.h"
#include <Preferences.h>
#include <math.h>

static Preferences prefs;

IMUDriver::IMUDriver()
    : gyro_bias_x(0.0f), gyro_bias_y(0.0f), gyro_bias_z(0.0f),
      accel_bias_x(0.0f), accel_bias_y(0.0f), accel_bias_z(0.0f),
      lpf_alpha_gyro(0.7f), lpf_alpha_accel(0.5f) {
    memset(&prev_filtered, 0, sizeof(ImuFilteredData));
}

bool IMUDriver::init(uint8_t sda_pin, uint8_t scl_pin, uint32_t frequency) {
    Wire.begin(sda_pin, scl_pin, frequency);
    Wire.setTimeOut(10); // 10ms timeout to avoid FreeRTOS blocking on bus lock

    delay(50);

    // Verify identity
    uint8_t whoami = readRegister(MPU_REG_WHO_AM_I);
    if (whoami != 0x68 && whoami != 0x70 && whoami != 0x72) {
        Serial.printf("[IMU] ERROR: MPU6050 not found! WhoAmI = 0x%02X\n", whoami);
        return false;
    }
    Serial.printf("[IMU] Found MPU6050 (0x%02X). Initializing...\n", whoami);

    // Reset device
    writeRegister(MPU_REG_PWR_MGMT_1, 0x80);
    delay(100);

    // Wake up, clock source = Auto Select (PLL with X-axis gyro reference or internal)
    writeRegister(MPU_REG_PWR_MGMT_1, 0x01);
    delay(15);

    // Digital Low Pass Filter (DLPF) Config: 42Hz DLPF bandwidth (Config = 0x03)
    // 1kHz internal sample rate, 4.8ms delay. Rejects motor vibration.
    writeRegister(MPU_REG_CONFIG, 0x03);

    // Sample Rate Divider: 1kHz / (1 + 1) = 500Hz
    writeRegister(MPU_REG_SMPLRT_DIV, 0x01);

    // Gyroscope Full Scale: ±2000 deg/s (FS_SEL = 3 -> 0x18)
    writeRegister(MPU_REG_GYRO_CONFIG, 0x18);

    // Accelerometer Full Scale: ±8g (AFS_SEL = 2 -> 0x10)
    writeRegister(MPU_REG_ACCEL_CONFIG, 0x10);

    // Configure interrupt & I2C bypass
    writeRegister(MPU_REG_INT_PIN_CFG, 0x02); // Enable I2C bypass for aux sensor access
    writeRegister(MPU_REG_INT_ENABLE, 0x00);  // Disable raw interrupts

    // Calculate LPF alpha values for 500Hz loop
    // alpha = dt / (RC + dt) = 2*pi*fc*dt / (2*pi*fc*dt + 1)
    setFilterCutoff(45.0f, 20.0f, (float)FLIGHT_LOOP_FREQ_HZ);

    // Try loading saved calibration from NVS
    if (!loadCalibration()) {
        Serial.println("[IMU] No stored calibration found. Running auto-calibration...");
        calibrateGyro(MPU6050_CALIB_SAMPLES);
        saveCalibration();
    }

    Serial.println("[IMU] MPU6050 initialized successfully at 500Hz!");
    return true;
}

void IMUDriver::setFilterCutoff(float gyro_lpf_hz, float accel_lpf_hz, float loop_rate_hz) {
    float dt = 1.0f / loop_rate_hz;

    // Gyro LPF Alpha
    float rc_gyro = 1.0f / (2.0f * 3.14159265f * gyro_lpf_hz);
    lpf_alpha_gyro = dt / (rc_gyro + dt);

    // Accel LPF Alpha
    float rc_accel = 1.0f / (2.0f * 3.14159265f * accel_lpf_hz);
    lpf_alpha_accel = dt / (rc_accel + dt);
}

bool IMUDriver::writeRegister(uint8_t reg, uint8_t data) {
    Wire.beginTransmission(MPU6050_I2C_ADDR);
    Wire.write(reg);
    Wire.write(data);
    return (Wire.endTransmission() == 0);
}

uint8_t IMUDriver::readRegister(uint8_t reg) {
    Wire.beginTransmission(MPU6050_I2C_ADDR);
    Wire.write(reg);
    Wire.endTransmission(false);
    Wire.requestFrom((uint8_t)MPU6050_I2C_ADDR, (uint8_t)1);
    if (Wire.available()) {
        return Wire.read();
    }
    return 0;
}

bool IMUDriver::readBytes(uint8_t reg, uint8_t *buffer, uint8_t length) {
    Wire.beginTransmission(MPU6050_I2C_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return false;
    }
    uint8_t count = Wire.requestFrom((uint8_t)MPU6050_I2C_ADDR, length);
    if (count != length) {
        return false;
    }
    for (uint8_t i = 0; i < length; i++) {
        buffer[i] = Wire.read();
    }
    return true;
}

bool IMUDriver::readRaw(ImuRawData &raw) {
    uint8_t buffer[14];
    if (!readBytes(MPU_REG_ACCEL_XOUT_H, buffer, 14)) {
        return false;
    }

    raw.ax   = (int16_t)((buffer[0] << 8) | buffer[1]);
    raw.ay   = (int16_t)((buffer[2] << 8) | buffer[3]);
    raw.az   = (int16_t)((buffer[4] << 8) | buffer[5]);
    raw.temp = (int16_t)((buffer[6] << 8) | buffer[7]);
    raw.gx   = (int16_t)((buffer[8] << 8) | buffer[9]);
    raw.gy   = (int16_t)((buffer[10] << 8) | buffer[11]);
    raw.gz   = (int16_t)((buffer[12] << 8) | buffer[13]);

    return true;
}

void IMUDriver::readFiltered(ImuFilteredData &filtered) {
    ImuRawData raw;
    if (!readRaw(raw)) {
        // In case of I2C read failure, preserve previous state
        filtered = prev_filtered;
        return;
    }

    // Convert raw to engineering units
    float raw_ax = ((float)raw.ax) * ACCEL_SCALE_FACTOR - accel_bias_x;
    float raw_ay = ((float)raw.ay) * ACCEL_SCALE_FACTOR - accel_bias_y;
    float raw_az = ((float)raw.az) * ACCEL_SCALE_FACTOR - accel_bias_z;

    float raw_gx = ((float)raw.gx) * GYRO_SCALE_FACTOR - gyro_bias_x;
    float raw_gy = ((float)raw.gy) * GYRO_SCALE_FACTOR - gyro_bias_y;
    float raw_gz = ((float)raw.gz) * GYRO_SCALE_FACTOR - gyro_bias_z;

    float temp = ((float)raw.temp) / 340.0f + 36.53f;

    // Apply software Exponential Moving Average (1st-order IIR Low-Pass Filter)
    filtered.ax = prev_filtered.ax + lpf_alpha_accel * (raw_ax - prev_filtered.ax);
    filtered.ay = prev_filtered.ay + lpf_alpha_accel * (raw_ay - prev_filtered.ay);
    filtered.az = prev_filtered.az + lpf_alpha_accel * (raw_az - prev_filtered.az);

    filtered.gx = prev_filtered.gx + lpf_alpha_gyro * (raw_gx - prev_filtered.gx);
    filtered.gy = prev_filtered.gy + lpf_alpha_gyro * (raw_gy - prev_filtered.gy);
    filtered.gz = prev_filtered.gz + lpf_alpha_gyro * (raw_gz - prev_filtered.gz);

    filtered.temp_c = temp;

    prev_filtered = filtered;
}

void IMUDriver::calibrateGyro(uint16_t sample_count) {
    Serial.println("[IMU] Keep the drone completely still on a level surface...");
    delay(1000);

    double sum_gx = 0, sum_gy = 0, sum_gz = 0;
    double sum_ax = 0, sum_ay = 0, sum_az = 0;
    uint16_t valid_samples = 0;

    for (uint16_t i = 0; i < sample_count; i++) {
        ImuRawData raw;
        if (readRaw(raw)) {
            sum_gx += (double)raw.gx * GYRO_SCALE_FACTOR;
            sum_gy += (double)raw.gy * GYRO_SCALE_FACTOR;
            sum_gz += (double)raw.gz * GYRO_SCALE_FACTOR;

            sum_ax += (double)raw.ax * ACCEL_SCALE_FACTOR;
            sum_ay += (double)raw.ay * ACCEL_SCALE_FACTOR;
            sum_az += (double)raw.az * ACCEL_SCALE_FACTOR;
            valid_samples++;
        }
        delay(2);
    }

    if (valid_samples > 100) {
        gyro_bias_x = (float)(sum_gx / valid_samples);
        gyro_bias_y = (float)(sum_gy / valid_samples);
        gyro_bias_z = (float)(sum_gz / valid_samples);

        accel_bias_x = (float)(sum_ax / valid_samples);
        accel_bias_y = (float)(sum_ay / valid_samples);
        // On level ground, 1.0g points upward along Z
        accel_bias_z = (float)(sum_az / valid_samples) - 1.0f;

        Serial.printf("[IMU] Calibration Complete! Gyro Biases (deg/s): [%.3f, %.3f, %.3f], Accel Biases (g): [%.3f, %.3f, %.3f]\n",
                      gyro_bias_x, gyro_bias_y, gyro_bias_z,
                      accel_bias_x, accel_bias_y, accel_bias_z);
    }
}

bool IMUDriver::loadCalibration() {
    if (!prefs.begin("drone_calib", true)) {
        return false;
    }
    bool exists = prefs.isKey("gx_bias");
    if (exists) {
        gyro_bias_x  = prefs.getFloat("gx_bias", 0.0f);
        gyro_bias_y  = prefs.getFloat("gy_bias", 0.0f);
        gyro_bias_z  = prefs.getFloat("gz_bias", 0.0f);
        accel_bias_x = prefs.getFloat("ax_bias", 0.0f);
        accel_bias_y = prefs.getFloat("ay_bias", 0.0f);
        accel_bias_z = prefs.getFloat("az_bias", 0.0f);
        Serial.printf("[IMU] Loaded Calibration from NVS: Gyro [%.3f, %.3f, %.3f], Accel [%.3f, %.3f, %.3f]\n",
                      gyro_bias_x, gyro_bias_y, gyro_bias_z,
                      accel_bias_x, accel_bias_y, accel_bias_z);
    }
    prefs.end();
    return exists;
}

void IMUDriver::saveCalibration() {
    if (prefs.begin("drone_calib", false)) {
        prefs.putFloat("gx_bias", gyro_bias_x);
        prefs.putFloat("gy_bias", gyro_bias_y);
        prefs.putFloat("gz_bias", gyro_bias_z);
        prefs.putFloat("ax_bias", accel_bias_x);
        prefs.putFloat("ay_bias", accel_bias_y);
        prefs.putFloat("az_bias", accel_bias_z);
        prefs.end();
        Serial.println("[IMU] Calibration saved to NVS flash successfully.");
    }
}
