#include "failsafe.h"

FailsafeManager::FailsafeManager()
    : battery_voltage(12.6f),
      battery_warning(false),
      battery_critical(false),
      arm_gesture_timer(0),
      disarm_gesture_timer(0),
      buzzer_timer(0),
      led_timer(0),
      led_state(false) {
}

void FailsafeManager::init() {
    pinMode(PIN_BATTERY_VOLTAGE, INPUT);
    pinMode(PIN_BUZZER, OUTPUT);
    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_BUZZER, LOW);
    digitalWrite(PIN_STATUS_LED, LOW);

    // Initial battery read
    updateBattery();

    // Startup beep sequence (3 short beeps)
    for (int i = 0; i < 3; i++) {
        digitalWrite(PIN_BUZZER, HIGH);
        digitalWrite(PIN_STATUS_LED, HIGH);
        delay(100);
        digitalWrite(PIN_BUZZER, LOW);
        digitalWrite(PIN_STATUS_LED, LOW);
        delay(100);
    }
}

void FailsafeManager::updateBattery() {
    // Read raw ADC (ESP32-S3 12-bit ADC: 0 - 4095)
    uint32_t raw_adc = analogRead(PIN_BATTERY_VOLTAGE);
    float pin_voltage = ((float)raw_adc / ADC_RESOLUTION) * ADC_VREF;
    float measured_vbat = pin_voltage * ADC_VOLTAGE_DIVIDER_RATIO;

    // Apply low-pass filter to battery voltage reading (alpha = 0.05)
    battery_voltage = battery_voltage * 0.95f + measured_vbat * 0.05f;

    // 3S LiPo Check
    if (battery_voltage < BATTERY_VOLTAGE_MIN_3S && battery_voltage > 6.0f) {
        battery_critical = true;
        battery_warning = true;
    } else if (battery_voltage < BATTERY_VOLTAGE_WARN_3S && battery_voltage > 6.0f) {
        battery_warning = true;
        battery_critical = false;
    } else {
        battery_warning = false;
        battery_critical = false;
    }
}

void FailsafeManager::update(const RadioControlPacket &rc_cmd,
                             const AttitudeEstimate &attitude,
                             bool radio_failsafe,
                             FlightState &current_state,
                             FlightMode  &current_mode) {
    // 1. Emergency Kill Switch (Aux 4 active)
    if (rc_cmd.aux4 > 0) {
        current_state = STATE_EMERGENCY_STOP;
        return;
    }

    // 2. Flip / Crash Detection (>55 degrees tilt angle while armed)
    if (current_state == STATE_ARMED) {
        if (fabsf(attitude.roll) > MAX_ALLOWED_ANGLE_DEG || fabsf(attitude.pitch) > MAX_ALLOWED_ANGLE_DEG) {
            Serial.println("[FAILSAFE] EMERGENCY CRASH DETECTED! Tilt angle exceeded safety limit! Disarming...");
            current_state = STATE_EMERGENCY_STOP;
            return;
        }
    }

    // 3. Radio Signal Loss / Failsafe
    if (radio_failsafe) {
        if (current_state == STATE_ARMED) {
            current_state = STATE_FAILSAFE;
        }
        return;
    }

    // 4. Update Flight Mode from AUX2 switch
    if (rc_cmd.aux2 == 0) {
        current_mode = MODE_ACRO;
    } else if (rc_cmd.aux2 == 1) {
        current_mode = MODE_STABILIZE;
    } else if (rc_cmd.aux2 >= 2) {
        current_mode = MODE_ALT_HOLD;
    }

    // 5. Arming & Disarming State Transitions
    // Check AUX1 Arm Switch OR Stick Gesture (Throttle down + Yaw right to ARM, Yaw left to DISARM)
    bool arm_switch_high = (rc_cmd.aux1 == 1);
    bool stick_arm_gesture = (rc_cmd.throttle < 1050 && rc_cmd.yaw > 1850);
    bool stick_disarm_gesture = (rc_cmd.throttle < 1050 && rc_cmd.yaw < 1150);

    if (current_state == STATE_DISARMED || current_state == STATE_EMERGENCY_STOP) {
        // Safe conditions to ARM:
        // - Throttle must be at minimum (< 1060us)
        // - Drone must be roughly level (< 25 deg tilt)
        // - Radio must be connected
        bool throttle_zero = (rc_cmd.throttle < 1060);
        bool drone_level = (fabsf(attitude.roll) < 25.0f && fabsf(attitude.pitch) < 25.0f);

        if (throttle_zero && drone_level && (arm_switch_high || stick_arm_gesture)) {
            if (arm_gesture_timer == 0) arm_gesture_timer = millis();
            if (millis() - arm_gesture_timer > 500) { // Hold for 500ms
                current_state = STATE_ARMED;
                Serial.println("[FAILSAFE] Drone successfully ARMED!");
                digitalWrite(PIN_BUZZER, HIGH);
                delay(200);
                digitalWrite(PIN_BUZZER, LOW);
                arm_gesture_timer = 0;
            }
        } else {
            arm_gesture_timer = 0;
        }
    } else if (current_state == STATE_ARMED) {
        // Disarming conditions:
        // - Arm switch set to 0 OR Throttle low + Yaw left for 500ms
        if (!arm_switch_high || stick_disarm_gesture) {
            if (disarm_gesture_timer == 0) disarm_gesture_timer = millis();
            if (millis() - disarm_gesture_timer > 250) {
                current_state = STATE_DISARMED;
                Serial.println("[FAILSAFE] Drone DISARMED.");
                digitalWrite(PIN_BUZZER, HIGH);
                delay(100);
                digitalWrite(PIN_BUZZER, LOW);
                delay(100);
                digitalWrite(PIN_BUZZER, HIGH);
                delay(100);
                digitalWrite(PIN_BUZZER, LOW);
                disarm_gesture_timer = 0;
            }
        } else {
            disarm_gesture_timer = 0;
        }
    }
}

void FailsafeManager::updateIndicators(FlightState state, FlightMode mode) {
    uint32_t now = millis();

    // LED Pattern
    if (state == STATE_ARMED) {
        // Solid ON when armed
        digitalWrite(PIN_STATUS_LED, HIGH);
    } else if (state == STATE_FAILSAFE) {
        // Fast flashing 10Hz when in failsafe
        if (now - led_timer > 100) {
            led_state = !led_state;
            digitalWrite(PIN_STATUS_LED, led_state ? HIGH : LOW);
            digitalWrite(PIN_BUZZER, led_state ? HIGH : LOW);
            led_timer = now;
        }
    } else {
        // Slow blinking 1Hz when disarmed
        if (now - led_timer > 500) {
            led_state = !led_state;
            digitalWrite(PIN_STATUS_LED, led_state ? HIGH : LOW);
            led_timer = now;
        }
    }

    // Low battery buzzer alarm
    if (battery_critical) {
        if (now - buzzer_timer > 200) {
            digitalWrite(PIN_BUZZER, !digitalRead(PIN_BUZZER));
            buzzer_timer = now;
        }
    } else if (battery_warning && state == STATE_ARMED) {
        if (now - buzzer_timer > 1000) {
            digitalWrite(PIN_BUZZER, HIGH);
            delay(50);
            digitalWrite(PIN_BUZZER, LOW);
            buzzer_timer = now;
        }
    }
}
