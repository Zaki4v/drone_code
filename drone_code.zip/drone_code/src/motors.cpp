#include "motors.h"

// LEDC Channels for ESP32-S3
#define LEDC_CH_M1              0
#define LEDC_CH_M2              1
#define LEDC_CH_M3              2
#define LEDC_CH_M4              3
#define LEDC_TIMER_RES_BITS     14        // 14-bit resolution: 0 - 16383
#define LEDC_MAX_DUTY           16383.0f
#define PWM_PERIOD_US           2500.0f   // 1 / 400Hz = 2500 microseconds

MotorDriver::MotorDriver() : armed(false) {
    current_outputs.m1 = MOTOR_PULSE_MIN;
    current_outputs.m2 = MOTOR_PULSE_MIN;
    current_outputs.m3 = MOTOR_PULSE_MIN;
    current_outputs.m4 = MOTOR_PULSE_MIN;
}

uint32_t MotorDriver::usToDuty(uint16_t us) {
    if (us < MOTOR_PULSE_MIN) us = MOTOR_PULSE_MIN;
    if (us > MOTOR_PULSE_MAX) us = MOTOR_PULSE_MAX;
    // Duty = (pulse_width / period) * (2^bits - 1)
    return (uint32_t)((float)us * (LEDC_MAX_DUTY / PWM_PERIOD_US));
}

void MotorDriver::init() {
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
    // ESP32 Arduino Core 3.x API
    ledcAttach(PIN_MOTOR_1, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
    ledcAttach(PIN_MOTOR_2, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
    ledcAttach(PIN_MOTOR_3, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
    ledcAttach(PIN_MOTOR_4, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
#else
    // ESP32 Arduino Core 2.x API
    ledcSetup(LEDC_CH_M1, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
    ledcSetup(LEDC_CH_M2, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
    ledcSetup(LEDC_CH_M3, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);
    ledcSetup(LEDC_CH_M4, ESC_PWM_FREQ_HZ, LEDC_TIMER_RES_BITS);

    ledcAttachPin(PIN_MOTOR_1, LEDC_CH_M1);
    ledcAttachPin(PIN_MOTOR_2, LEDC_CH_M2);
    ledcAttachPin(PIN_MOTOR_3, LEDC_CH_M3);
    ledcAttachPin(PIN_MOTOR_4, LEDC_CH_M4);
#endif

    // Initial safe state: motors fully stopped
    disarm();
    Serial.println("[MOTORS] Hardware 400Hz MCPWM/LEDC Timer initialized for 40A ESCs.");
}

void MotorDriver::arm() {
    armed = true;
    writeAll(MOTOR_PULSE_ARM_IDLE);
    Serial.println("[MOTORS] ARMED: Idle throttle engaged.");
}

void MotorDriver::disarm() {
    armed = false;
    writeAll(MOTOR_PULSE_MIN);
    Serial.println("[MOTORS] DISARMED: Motor pulses set to 1000us.");
}

void MotorDriver::writeMicroseconds(uint8_t motor_idx, uint16_t us) {
    uint32_t duty = usToDuty(us);
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
    switch (motor_idx) {
        case 0: ledcWrite(PIN_MOTOR_1, duty); current_outputs.m1 = us; break;
        case 1: ledcWrite(PIN_MOTOR_2, duty); current_outputs.m2 = us; break;
        case 2: ledcWrite(PIN_MOTOR_3, duty); current_outputs.m3 = us; break;
        case 3: ledcWrite(PIN_MOTOR_4, duty); current_outputs.m4 = us; break;
    }
#else
    switch (motor_idx) {
        case 0: ledcWrite(LEDC_CH_M1, duty); current_outputs.m1 = us; break;
        case 1: ledcWrite(LEDC_CH_M2, duty); current_outputs.m2 = us; break;
        case 2: ledcWrite(LEDC_CH_M3, duty); current_outputs.m3 = us; break;
        case 3: ledcWrite(LEDC_CH_M4, duty); current_outputs.m4 = us; break;
    }
#endif
}

void MotorDriver::writeAll(uint16_t us) {
    for (uint8_t i = 0; i < 4; i++) {
        writeMicroseconds(i, us);
    }
}

void MotorDriver::mixAndWrite(uint16_t base_throttle, float roll_cmd, float pitch_cmd, float yaw_cmd) {
    if (!armed || base_throttle < MOTOR_PULSE_ARM_IDLE) {
        // Disarmed or throttle below idle -> cut motors
        writeAll(MOTOR_PULSE_MIN);
        return;
    }

    // Quad-X Mixing Equations:
    // M1 (Front-Right, CCW): Throttle - Roll - Pitch + Yaw
    // M2 (Rear-Right,  CW):  Throttle - Roll + Pitch - Yaw
    // M3 (Rear-Left,   CCW): Throttle + Roll + Pitch + Yaw
    // M4 (Front-Left,  CW):  Throttle + Roll - Pitch - Yaw
    float m1_calc = (float)base_throttle - roll_cmd - pitch_cmd + yaw_cmd;
    float m2_calc = (float)base_throttle - roll_cmd + pitch_cmd - yaw_cmd;
    float m3_calc = (float)base_throttle + roll_cmd + pitch_cmd + yaw_cmd;
    float m4_calc = (float)base_throttle + roll_cmd - pitch_cmd - yaw_cmd;

    // Find maximum command across all motors for anti-saturation scaling
    float max_m = m1_calc;
    if (m2_calc > max_m) max_m = m2_calc;
    if (m3_calc > max_m) max_m = m3_calc;
    if (m4_calc > max_m) max_m = m4_calc;

    // If any motor exceeds maximum pulse, scale down equally to prevent loss of roll/pitch authority
    if (max_m > MOTOR_PULSE_MAX) {
        float excess = max_m - MOTOR_PULSE_MAX;
        m1_calc -= excess;
        m2_calc -= excess;
        m3_calc -= excess;
        m4_calc -= excess;
    }

    // Find minimum command across all motors
    float min_m = m1_calc;
    if (m2_calc < min_m) min_m = m2_calc;
    if (m3_calc < min_m) min_m = m3_calc;
    if (m4_calc < min_m) min_m = m4_calc;

    if (min_m < MOTOR_PULSE_ARM_IDLE) {
        float deficit = MOTOR_PULSE_ARM_IDLE - min_m;
        m1_calc += deficit;
        m2_calc += deficit;
        m3_calc += deficit;
        m4_calc += deficit;
    }

    // Final boundary clamp & write
    writeMicroseconds(0, (uint16_t)constrain(m1_calc, MOTOR_PULSE_ARM_IDLE, MOTOR_PULSE_MAX));
    writeMicroseconds(1, (uint16_t)constrain(m2_calc, MOTOR_PULSE_ARM_IDLE, MOTOR_PULSE_MAX));
    writeMicroseconds(2, (uint16_t)constrain(m3_calc, MOTOR_PULSE_ARM_IDLE, MOTOR_PULSE_MAX));
    writeMicroseconds(3, (uint16_t)constrain(m4_calc, MOTOR_PULSE_ARM_IDLE, MOTOR_PULSE_MAX));
}

void MotorDriver::runCalibrationSequence() {
    Serial.println("=================================================");
    Serial.println(">>> STARTING 40A ESC CALIBRATION SEQUENCE <<<");
    Serial.println("DISCONNECT PROPELLERS! DANGER OF INJURY!");
    Serial.println("1. Setting throttle HIGH (2000us)...");
    Serial.println("2. Connect LiPo Battery NOW!");
    Serial.println("=================================================");
    writeAll(MOTOR_PULSE_CALIB_HIGH);
    delay(4000); // Wait for ESCs to power up and detect max throttle beep

    Serial.println("3. Setting throttle LOW (1000us)...");
    writeAll(MOTOR_PULSE_CALIB_LOW);
    delay(3000); // Wait for ESC confirmation tones

    Serial.println(">>> ESC CALIBRATION COMPLETE! <<<");
    Serial.println("=================================================");
}
