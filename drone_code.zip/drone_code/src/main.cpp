#include <Arduino.h>
#include "config.h"
#include "types.h"
#include "imu.h"
#include "baro_aht.h"
#include "attitude.h"
#include "pid.h"
#include "motors.h"
#include "radio.h"
#include "failsafe.h"

// =============================================================================
// GLOBAL OBJECTS
// =============================================================================
IMUDriver           imu;
BaroAhtDriver       baro_aht;
MahonyAHRS          ahrs;
FlightPIDController pid;
MotorDriver         motors;
RadioDriver         radio_txrx;
FailsafeManager     failsafe;

// State Variables
FlightState current_state = STATE_DISARMED;
FlightMode  current_mode  = MODE_STABILIZE;

RadioControlPacket   rc_in;
RadioTelemetryPacket telem_out;

float throttle_failsafe_val = 0;

// FreeRTOS Task Handles
TaskHandle_t FlightLoopTask_Handle;
TaskHandle_t NavCommsTask_Handle;

// =============================================================================
// HELPER MAP FUNCTION (Floating Point)
// =============================================================================
float mapf(float x, float in_min, float in_max, float out_min, float out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

// =============================================================================
// CORE 1: HIGH PRIORITY 500Hz FLIGHT CONTROL LOOP
// =============================================================================
void FlightLoopTask(void *pvParameters) {
    TickType_t xLastWakeTime;
    const TickType_t xFrequency = pdMS_TO_TICKS((int)(1000.0f / FLIGHT_LOOP_FREQ_HZ)); // 2ms ticks
    xLastWakeTime = xTaskGetTickCount();

    ImuFilteredData imu_data;
    AttitudeEstimate attitude;

    for (;;) {
        // 1. Read and Filter Sensors (I2C ~400us block)
        imu.readFiltered(imu_data);

        // 2. Mahony Attitude Estimation (~5us block)
        ahrs.update(imu_data.gx, imu_data.gy, imu_data.gz,
                    imu_data.ax, imu_data.ay, imu_data.az,
                    FLIGHT_LOOP_DT, attitude);

        // 3. Command Processing
        float target_roll_deg = mapf((float)rc_in.roll, 1000.0f, 2000.0f, -30.0f, 30.0f);
        float target_pitch_deg = mapf((float)rc_in.pitch, 1000.0f, 2000.0f, -30.0f, 30.0f);
        float target_yaw_rate = mapf((float)rc_in.yaw, 1000.0f, 2000.0f, -120.0f, 120.0f);
        float base_throttle = (float)rc_in.throttle;

        // Apply deadbands
        if (fabsf(target_roll_deg) < 1.0f) target_roll_deg = 0.0f;
        if (fabsf(target_pitch_deg) < 1.0f) target_pitch_deg = 0.0f;
        if (fabsf(target_yaw_rate) < 2.0f) target_yaw_rate = 0.0f;

        // Handle ALTHOLD mode
        if (current_mode == MODE_ALT_HOLD && current_state == STATE_ARMED && base_throttle > 1400 && base_throttle < 1600) {
            // Altitude hold engaged (Throttle centered)
            // Implementation: Maintain last altitude by overriding base_throttle
            static float target_altitude = -1.0f;
            if (target_altitude < 0) {
                target_altitude = baro_aht.getAltitude();
            }
            float alt_throttle_correction = pid.updateAltitude(target_altitude, baro_aht.getAltitude(), baro_aht.getClimbRate(), FLIGHT_LOOP_DT);
            base_throttle = mapf((float)rc_in.throttle, 1000, 2000, (float)MOTOR_PULSE_ARM_IDLE, (float)MOTOR_PULSE_MAX) + alt_throttle_correction;
        }

        // Failsafe Descent handling (Auto-Land logic)
        if (current_state == STATE_FAILSAFE) {
            target_roll_deg = 0.0f;
            target_pitch_deg = 0.0f;
            target_yaw_rate = 0.0f;
            base_throttle = throttle_failsafe_val;
            throttle_failsafe_val -= (FAILSAFE_DESCENT_RATE * FLIGHT_LOOP_DT); // slowly decrement throttle
            if (throttle_failsafe_val < MOTOR_PULSE_MIN) {
                current_state = STATE_DISARMED;
            }
        }

        // Emergency Drop handling
        if (current_state == STATE_EMERGENCY_STOP) {
            base_throttle = 1000.0f;
            pid.reset();
        }

        // 4. Update PID Matrix (~10us block)
        float roll_pid_out, pitch_pid_out, yaw_pid_out;

        if (current_state == STATE_ARMED || current_state == STATE_FAILSAFE) {
            pid.update(current_mode, target_roll_deg, target_pitch_deg, target_yaw_rate,
                       attitude, imu_data, FLIGHT_LOOP_DT,
                       roll_pid_out, pitch_pid_out, yaw_pid_out);
        } else {
            roll_pid_out = pitch_pid_out = yaw_pid_out = 0.0f;
            pid.reset(); // Don't accumulate errors while disarmed
        }

        // 5. Motor Mixing and Output
        if (current_state == STATE_ARMED || current_state == STATE_FAILSAFE) {
            motors.mixAndWrite((uint16_t)base_throttle, roll_pid_out, pitch_pid_out, yaw_pid_out);
            if (!motors.isArmed()) motors.arm();
        } else {
            motors.disarm();
        }

        // Sleep until next ~2ms tick
        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// =============================================================================
// CORE 0: 100Hz COMMUNICATIONS, TELEMETRY, & NAVIGATION LOOP
// =============================================================================
void NavCommsTask(void *pvParameters) {
    TickType_t xLastWakeTime;
    const TickType_t xFrequency = pdMS_TO_TICKS((int)(1000.0f / COMMS_TASK_FREQ_HZ)); // 10ms ticks
    xLastWakeTime = xTaskGetTickCount();

    uint16_t slow_loop_counter = 0;

    for (;;) {
        // 1. Radio Receive & Drone State / Arming Fused Checks
        bool new_radio_data = radio_txrx.receiveControl(rc_in);

        failsafe.update(rc_in, ahrs, radio_txrx.isFailsafeActive(), current_state, current_mode);

        if (radio_txrx.isFailsafeActive() && current_state == STATE_FAILSAFE) {
            if (throttle_failsafe_val == 0) {
                throttle_failsafe_val = (float)rc_in.throttle; // Start descent from last known throttle
            }
        } else {
            throttle_failsafe_val = 0;
        }

        failsafe.updateIndicators(current_state, current_mode);

        // 2. Barometer kalman update (Run at 50Hz)
        if (slow_loop_counter % 2 == 0) {
            // Need vertical Z acceleration rotated from body frame to earth frame
            // Approx using roll/pitch projection
            float cos_r = cos(ahrs.getRoll() * 0.01745f);
            float cos_p = cos(ahrs.getPitch() * 0.01745f);
            float vertical_accel = 0.0f; // Placeholder: Real fusion requires taking az and applying rotation matrix

            baro_aht.updateBaro(vertical_accel, 0.02f); // 20ms dt -> 50hz
        }

        // 3. AHT20 Temp/Humid update (Run at 1Hz)
        if (slow_loop_counter % 100 == 0) {
            baro_aht.updateAht();
            failsafe.updateBattery();
        }

        // 4. Telemetry Pack & Send downlink via ACK payload feature
        if (new_radio_data && (slow_loop_counter % 5 == 0)) { // ~20Hz Telemetry
            telem_out.roll_deg_x10 = (int16_t)(ahrs.getRoll() * 10.0f);
            telem_out.pitch_deg_x10 = (int16_t)(ahrs.getPitch() * 10.0f);
            telem_out.yaw_deg_x10 = (int16_t)(ahrs.getYaw() * 10.0f);
            telem_out.altitude_cm = (int16_t)(baro_aht.getAltitude() * 100.0f);
            telem_out.vspeed_cms = (int16_t)(baro_aht.getClimbRate() * 100.0f);
            telem_out.vbat_mv = failsafe.getBatteryVoltageMv();
            telem_out.flight_mode = current_mode;
            telem_out.flight_state = current_state;
            telem_out.rssi_quality = radio_txrx.getLinkQuality();

            // Simple XOR Checksum
            uint8_t *b = (uint8_t*)&telem_out;
            uint8_t chk = 0;
            for (size_t i=0; i<sizeof(RadioTelemetryPacket)-1; i++) chk ^= b[i];
            telem_out.checksum = chk;

            radio_txrx.sendTelemetry(telem_out);
        }

        slow_loop_counter++;
        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// =============================================================================
// SETUP: HARDWARE BOOTSTRAP
// =============================================================================
void setup() {
    Serial.begin(115200);
    delay(2000); // 2s boot delay to let everything settle
    Serial.println("\n\n>>> PROFESSIONAL ESP32-S3 DRONE FIRMWARE BOOT <<<");

    // Initialize failsafe & indicators first
    failsafe.init();
    Serial.println("System Hardware initialized.");

    // Initialize Motor Timers
    motors.init();

    // Check if ESC Calibration is forced via BOOT switch (GPIO0)
    pinMode(0, INPUT_PULLUP);
    if (digitalRead(0) == LOW) {
        motors.runCalibrationSequence();
        // Wait forever after calibration
        while (1) { delay(1000); }
    }

    // Initialize Sensors
    if (!imu.init()) {
        Serial.println("CRITICAL: IMU INIT FAILED. HALTING.");
        while(1) { failsafe.beep(1000, 500); delay(500); }
    }

    baro_aht.init();
    ahrs.reset();
    pid.init();

    // Initialize PA/LNA Radio
    if (!radio_txrx.init()) {
        Serial.println("CRITICAL: NRF24 INIT FAILED. HALTING.");
        while(1) { failsafe.beep(200, 100); delay(100); }
    }

    // Set default failsafe packet values
    rc_in.throttle = 1000;
    rc_in.roll = 1500;
    rc_in.pitch = 1500;
    rc_in.yaw = 1500;
    rc_in.aux1 = 0;
    rc_in.aux2 = 1;
    rc_in.aux4 = 0;

    Serial.println("Spawning FreeRTOS tasks to cores...");

    // Spawn 500Hz Real-Time Flight Loop to Core 1 (App Core) with high priority
    xTaskCreatePinnedToCore(
        FlightLoopTask,
        "FlightLoopTask",
        8192,
        NULL,
        configMAX_PRIORITIES - 1,
        &FlightLoopTask_Handle,
        1 // CORE 1
    );

    // Spawn 100Hz Navigation/Radio/Sensors Loop to Core 0 (Pro Core) with standard priority
    xTaskCreatePinnedToCore(
        NavCommsTask,
        "NavCommsTask",
        8192,
        NULL,
        configMAX_PRIORITIES - 2,
        &NavCommsTask_Handle,
        0 // CORE 0
    );

    Serial.println(">>> BOOT SEQUENCE COMPLETE. READY TO ARM. <<<");
}

// Ensure loop() gets optimized away as FreeRTOS handles the tasks
void loop() {
    vTaskDelete(NULL);
}
