#include "radio.h"

RadioDriver::RadioDriver()
    : radio(PIN_NRF_CE, PIN_NRF_CSN),
      spi_bus(FSPI),
      last_packet_time_ms(0),
      failsafe_active(true),
      packets_received_window(0),
      last_stats_calc_time_ms(0),
      link_quality_pct(0),
      last_seq_num(0) {
}

uint16_t RadioDriver::calculateCrc16(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc = crc >> 1;
            }
        }
    }
    return crc;
}

bool RadioDriver::init() {
    // Initialize SPI bus for ESP32-S3
    spi_bus.begin(PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI, PIN_NRF_CSN);

    // Initialize RF24 radio using the custom SPI instance
    if (!radio.begin(&spi_bus)) {
        Serial.println("[RADIO] ERROR: nRF24L01+ PA/LNA hardware initialization failed!");
        return false;
    }

    // Configure Radio for Long Range and High Reliability
    radio.setChannel(NRF_CHANNEL);                     // 2.508 GHz
    radio.setDataRate(NRF_DATA_RATE);                  // 250 kbps
    radio.setPALevel(NRF_PA_LEVEL);                    // Max Power (+20dBm with PA/LNA)
    radio.setAutoAck(true);                            // Auto ACK enabled
    radio.enableAckPayload();                          // Enable ACK payload for instant telemetry
    radio.enableDynamicPayloads();                     // Dynamic payloads
    radio.setCRCLength(RF24_CRC_16);                   // 16-bit CRC
    radio.setRetries(3, 15);                           // 3 * 250us = 750us delay, 15 retries

    // Open Pipes
    radio.openWritingPipe(NRF_PIPE_TX);
    radio.openReadingPipe(1, NRF_PIPE_RX);

    radio.startListening();

    last_packet_time_ms = millis();
    last_stats_calc_time_ms = millis();
    failsafe_active = true;

    Serial.println("[RADIO] nRF24L01+ PA/LNA initialized successfully on channel 108 @ 250kbps!");
    return true;
}

bool RadioDriver::receiveControl(RadioControlPacket &ctrl) {
    bool packet_received = false;

    while (radio.available()) {
        uint8_t payload_size = radio.getDynamicPayloadSize();
        if (payload_size == sizeof(RadioControlPacket)) {
            RadioControlPacket temp_packet;
            radio.read(&temp_packet, sizeof(RadioControlPacket));

            // Verify CRC16 Checksum
            uint16_t computed_crc = calculateCrc16((const uint8_t *)&temp_packet, sizeof(RadioControlPacket) - sizeof(uint16_t));
            if (computed_crc == temp_packet.checksum) {
                ctrl = temp_packet;
                last_packet_time_ms = millis();
                packets_received_window++;
                failsafe_active = false;
                packet_received = true;
                last_seq_num = temp_packet.packet_seq;
            } else {
                Serial.println("[RADIO] Warning: Packet CRC mismatch, packet dropped.");
            }
        } else {
            // Flush invalid length packet
            uint8_t dummy[32];
            radio.read(dummy, payload_size);
        }
    }

    // Check for signal loss / Failsafe timeout
    if (millis() - last_packet_time_ms > RADIO_TIMEOUT_MS) {
        failsafe_active = true;
    }

    updateLinkStats();
    return packet_received;
}

bool RadioDriver::sendTelemetry(const RadioTelemetryPacket &telem) {
    // Load telemetry data into next ACK payload
    radio.writeAckPayload(1, &telem, sizeof(RadioTelemetryPacket));
    return true;
}

void RadioDriver::updateLinkStats() {
    uint32_t now = millis();
    if (now - last_stats_calc_time_ms >= 1000) {
        // Expected packets per second = 50 - 100 Hz from transmitter
        float expected_packets = 50.0f;
        float ratio = (float)packets_received_window / expected_packets;
        if (ratio > 1.0f) ratio = 1.0f;
        link_quality_pct = (uint8_t)(ratio * 100.0f);

        packets_received_window = 0;
        last_stats_calc_time_ms = now;
    }
}
