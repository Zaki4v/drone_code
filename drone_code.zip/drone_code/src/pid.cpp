#include "pid.h"
#include <math.h>

PIDAxis::PIDAxis()
    : kp(0.0f), ki(0.0f), kd(0.0f), i_max(100.0f),
      integral(0.0f), prev_measurement(0.0f), prev_error(0.0f),
      d_filter_alpha(0.6f), d_term_filtered(0.0f),
      p_term(0.0f), i_term(0.0f), d_term(0.0f), last_output(0.0f) {
}

void PIDAxis::init(float kp_val, float ki_val, float kd_val, float i_max_val, float d_cutoff_hz, float loop_rate_hz) {
    kp = kp_val;
    ki = ki_val;
    kd = kd_val;
    i_max = i_max_val;
    reset();

    // D-term Low-Pass Filter Alpha calculation
    float dt = 1.0f / loop_rate_hz;
    float rc = 1.0f / (2.0f * 3.14159265f * d_cutoff_hz);
    d_filter_alpha = dt / (rc + dt);
}

void PIDAxis::reset() {
    integral = 0.0f;
    prev_measurement = 0.0f;
    prev_error = 0.0f;
    d_term_filtered = 0.0f;
    p_term = 0.0f;
    i_term = 0.0f;
    d_term = 0.0f;
    last_output = 0.0f;
}

void PIDAxis::setGains(float kp_val, float ki_val, float kd_val, float i_max_val) {
    kp = kp_val;
    ki = ki_val;
    kd = kd_val;
    i_max = i_max_val;
}

float PIDAxis::update(float target, float current, float dt) {
    if (dt <= 0.0f) return last_output;

    float error = target - current;

    // Proportional Term
    p_term = kp * error;

    // Integral Term with anti-windup clamping
    integral += ki * error * dt;
    if (integral > i_max) integral = i_max;
    else if (integral < -i_max) integral = -i_max;
    i_term = integral;

    // Derivative on Measurement (avoids derivative kick on setpoint change)
    float raw_d = -kd * (current - prev_measurement) / dt;
    prev_measurement = current;

    // Low-pass filter the D-term
    d_term_filtered = d_term_filtered + d_filter_alpha * (raw_d - d_term_filtered);
    d_term = d_term_filtered;

    last_output = p_term + i_term + d_term;
    return last_output;
}

float PIDAxis::updateRate(float target_rate, float current_gyro_rate, float dt) {
    if (dt <= 0.0f) return last_output;

    float error = target_rate - current_gyro_rate;

    // Proportional
    p_term = kp * error;

    // Integral with anti-windup
    integral += ki * error * dt;
    if (integral > i_max) integral = i_max;
    else if (integral < -i_max) integral = -i_max;
    i_term = integral;

    // D-term calculated directly on gyro rate delta
    float raw_d = -kd * (current_gyro_rate - prev_measurement) / dt;
    prev_measurement = current_gyro_rate;

    // Filtered D-term to suppress motor high-frequency noise
    d_term_filtered = d_term_filtered + d_filter_alpha * (raw_d - d_term_filtered);
    d_term = d_term_filtered;

    last_output = p_term + i_term + d_term;
    return last_output;
}

// =============================================================================
// Cascaded Master Controller
// =============================================================================

FlightPIDController::FlightPIDController() {
}

void FlightPIDController::init() {
    // Initialize Angle Controllers (Outer Loop)
    roll_angle_pid.init(PID_ROLL_ANGLE_KP, PID_ROLL_ANGLE_KI, PID_ROLL_ANGLE_KD, 0.0f, 30.0f, FLIGHT_LOOP_FREQ_HZ);
    pitch_angle_pid.init(PID_PITCH_ANGLE_KP, PID_PITCH_ANGLE_KI, PID_PITCH_ANGLE_KD, 0.0f, 30.0f, FLIGHT_LOOP_FREQ_HZ);

    // Initialize Rate Controllers (Inner Loop)
    roll_rate_pid.init(PID_ROLL_RATE_KP, PID_ROLL_RATE_KI, PID_ROLL_RATE_KD, PID_ROLL_RATE_I_MAX, 35.0f, FLIGHT_LOOP_FREQ_HZ);
    pitch_rate_pid.init(PID_PITCH_RATE_KP, PID_PITCH_RATE_KI, PID_PITCH_RATE_KD, PID_PITCH_RATE_I_MAX, 35.0f, FLIGHT_LOOP_FREQ_HZ);
    yaw_rate_pid.init(PID_YAW_RATE_KP, PID_YAW_RATE_KI, PID_YAW_RATE_KD, PID_YAW_RATE_I_MAX, 25.0f, FLIGHT_LOOP_FREQ_HZ);

    // Initialize Altitude Hold Controller
    alt_pid.init(PID_ALT_KP, PID_ALT_KI, PID_ALT_KD, PID_ALT_I_MAX, 15.0f, FLIGHT_LOOP_FREQ_HZ);
}

void FlightPIDController::reset() {
    roll_angle_pid.reset();
    pitch_angle_pid.reset();
    roll_rate_pid.reset();
    pitch_rate_pid.reset();
    yaw_rate_pid.reset();
    alt_pid.reset();
}

void FlightPIDController::update(FlightMode mode,
                                 float target_roll_deg, float target_pitch_deg, float target_yaw_rate_degs,
                                 const AttitudeEstimate &attitude,
                                 const ImuFilteredData &imu,
                                 float dt,
                                 float &roll_out, float &pitch_out, float &yaw_out) {
    float target_roll_rate  = 0.0f;
    float target_pitch_rate = 0.0f;

    if (mode == MODE_STABILIZE || mode == MODE_ALT_HOLD) {
        // --- Angle Mode (Cascaded Dual-Loop) ---
        // 1. Outer Loop: Calculate desired angular rate based on angle error
        float roll_angle_err  = target_roll_deg - attitude.roll;
        float pitch_angle_err = target_pitch_deg - attitude.pitch;

        target_roll_rate  = roll_angle_pid.update(target_roll_deg, attitude.roll, dt);
        target_pitch_rate = pitch_angle_pid.update(target_pitch_deg, attitude.pitch, dt);

        // Clamp desired rates to limits
        if (target_roll_rate > PID_ROLL_ANGLE_LIMIT) target_roll_rate = PID_ROLL_ANGLE_LIMIT;
        else if (target_roll_rate < -PID_ROLL_ANGLE_LIMIT) target_roll_rate = -PID_ROLL_ANGLE_LIMIT;

        if (target_pitch_rate > PID_PITCH_ANGLE_LIMIT) target_pitch_rate = PID_PITCH_ANGLE_LIMIT;
        else if (target_pitch_rate < -PID_PITCH_ANGLE_LIMIT) target_pitch_rate = -PID_PITCH_ANGLE_LIMIT;
    } else {
        // --- Acro Mode: Direct Rate Control ---
        target_roll_rate  = target_roll_deg;  // In acro mode, input represents desired deg/s
        target_pitch_rate = target_pitch_deg; // In acro mode, input represents desired deg/s
    }

    // 2. Inner Loop: Calculate motor control effort using gyro rate
    roll_out  = roll_rate_pid.updateRate(target_roll_rate, imu.gx, dt);
    pitch_out = pitch_rate_pid.updateRate(target_pitch_rate, imu.gy, dt);
    yaw_out   = yaw_rate_pid.updateRate(target_yaw_rate_degs, imu.gz, dt);
}

float FlightPIDController::updateAltitude(float target_alt_m, float current_alt_m, float vertical_vel_ms, float dt) {
    // Altitude PID + Velocity Damping
    float alt_error = target_alt_m - current_alt_m;
    float alt_effort = alt_pid.update(target_alt_m, current_alt_m, dt);

    // Add negative damping against vertical velocity
    float d_damping = -PID_ALT_KD * vertical_vel_ms * 10.0f;
    return alt_effort + d_damping;
}

void FlightPIDController::setAngleGains(float roll_kp, float pitch_kp) {
    roll_angle_pid.setGains(roll_kp, 0.0f, 0.0f, 0.0f);
    pitch_angle_pid.setGains(pitch_kp, 0.0f, 0.0f, 0.0f);
}

void FlightPIDController::setRateGains(float r_kp, float r_ki, float r_kd,
                                       float p_kp, float p_ki, float p_kd,
                                       float y_kp, float y_ki, float y_kd) {
    roll_rate_pid.setGains(r_kp, r_ki, r_kd, PID_ROLL_RATE_I_MAX);
    pitch_rate_pid.setGains(p_kp, p_ki, p_kd, PID_PITCH_RATE_I_MAX);
    yaw_rate_pid.setGains(y_kp, y_ki, y_kd, PID_YAW_RATE_I_MAX);
}
