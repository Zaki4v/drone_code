#pragma once

#include <Arduino.h>

// =============================================================================
// TRANSMITTER HARDWARE PIN DEFINITIONS (ESP32 or Arduino Compatible)
// =============================================================================

// Joysticks (Analog Inputs)
#define PIN_STICK_THROTTLE      34 // Left Stick Vertical
#define PIN_STICK_YAW           35 // Left Stick Horizontal
#define PIN_STICK_PITCH         36 // Right Stick Vertical (VP)
#define PIN_STICK_ROLL          39 // Right Stick Horizontal (VN)

// Switches
#define PIN_SW_ARM              15 // Toggle switch for ARM/DISARM
#define PIN_SW_MODE             4  // Toggle switch (Acro / Stabilize / AltHold)
#define PIN_SW_KILL             16 // Emergency Kill Switch (Momentary or latching)

// nRF24L01+ Pins
#define PIN_TX_NRF_CE           5
#define PIN_TX_NRF_CSN          17

// Display (I2C SSD1306 OLED optional)
#define PIN_OLED_SDA            21
#define PIN_OLED_SCL            22

// Radio Settings (Must match Drone config.h)
#define NRF_CHANNEL             108
#define NRF_PIPE_TX             0xE8E8F0F0D2LL // Drone RX Pipe
#define NRF_PIPE_RX             0xE8E8F0F0E1LL // Drone TX Pipe
