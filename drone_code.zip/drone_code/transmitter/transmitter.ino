#include <Arduino.h>
#include <SPI.h>
#include <RF24.h>
#include "transmitter_config.h"

// Import matching packet types
struct __attribute__((packed)) RadioControlPacket {
    uint16_t throttle;    // 1000 - 2000 us
    int16_t  roll;        // 1000 - 2000 us (Center: 1500)
    int16_t  pitch;       // 1000 - 2000 us (Center: 1500)
    int16_t  yaw;         // 1000 - 2000 us (Center: 1500)
    uint8_t  aux1;        // Arm Switch (0: Disarm, 1: Arm)
    uint8_t  aux2;        // Flight Mode (0: Acro, 1: Stabilize, 2: AltHold)
    uint8_t  aux3;        // Buzzer / Extra switch (0/1)
    uint8_t  aux4;        // Emergency Kill switch (0/1)
    uint16_t packet_seq;  // Packet sequence counter
    uint16_t checksum;    // CRC16 verification
};

struct __attribute__((packed)) RadioTelemetryPacket {
    int16_t  roll_deg_x10;
    int16_t  pitch_deg_x10;
    int16_t  yaw_deg_x10;
    int16_t  altitude_cm;
    int16_t  vspeed_cms;
    uint16_t vbat_mv;
    int16_t  temp_aht_x10;
    uint16_t humidity_x10;
    uint8_t  flight_state;
    uint8_t  flight_mode;
    uint8_t  rssi_quality;
    uint8_t  checksum;
};

RF24 tx_radio(PIN_TX_NRF_CE, PIN_TX_NRF_CSN);
RadioControlPacket tx_packet;
RadioTelemetryPacket rx_telemetry;

uint16_t seq_counter = 0;
uint32_t last_tx_time = 0;
uint32_t last_telem_print = 0;
bool telemetry_received = false;

uint16_t calculateCrc16(const uint8_t *data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x0001) crc = (crc >> 1) ^ 0xA001;
            else crc = crc >> 1;
        }
    }
    return crc;
}

uint16_t readChannel(uint8_t pin, uint16_t min_cal, uint16_t center_cal, uint16_t max_cal, bool reverse = false) {
    int raw = analogRead(pin); // 0 - 4095
    int mapped = 0;
    if (raw < center_cal) {
        mapped = map(raw, min_cal, center_cal, 1000, 1500);
    } else {
        mapped = map(raw, center_cal, max_cal, 1500, 2000);
    }
    mapped = constrain(mapped, 1000, 2000);
    if (reverse) {
        mapped = 3000 - mapped;
    }
    return (uint16_t)mapped;
}

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("\n>>> PROFESSIONAL DRONE TRANSMITTER BOOT <<<");

    pinMode(PIN_SW_ARM, INPUT_PULLUP);
    pinMode(PIN_SW_MODE, INPUT_PULLUP);
    pinMode(PIN_SW_KILL, INPUT_PULLUP);

    if (!tx_radio.begin()) {
        Serial.println("[TX] ERROR: nRF24L01+ hardware failure!");
        while (1) { delay(500); }
    }

    tx_radio.setChannel(NRF_CHANNEL);
    tx_radio.setDataRate(RF24_250KBPS);
    tx_radio.setPALevel(RF24_PA_MAX);
    tx_radio.setAutoAck(true);
    tx_radio.enableAckPayload();
    tx_radio.enableDynamicPayloads();
    tx_radio.setCRCLength(RF24_CRC_16);
    tx_radio.setRetries(2, 10);

    tx_radio.openWritingPipe(NRF_PIPE_TX);
    tx_radio.openReadingPipe(1, NRF_PIPE_RX);
    tx_radio.stopListening(); // Transmit Mode

    Serial.println("[TX] Transmitter Radio Ready on Channel 108!");
}

void loop() {
    uint32_t now = millis();

    // Transmit Control Packets at 50Hz (every 20ms)
    if (now - last_tx_time >= 20) {
        last_tx_time = now;

        // Read Joystick Inputs (12-bit ADC mapped to 1000 - 2000 microseconds)
        tx_packet.throttle = readChannel(PIN_STICK_THROTTLE, 0, 2048, 4095, false);
        tx_packet.yaw      = readChannel(PIN_STICK_YAW,      0, 2048, 4095, false);
        tx_packet.pitch    = readChannel(PIN_STICK_PITCH,    0, 2048, 4095, false);
        tx_packet.roll     = readChannel(PIN_STICK_ROLL,     0, 2048, 4095, false);

        // Read Switches (Active LOW with internal pull-up)
        tx_packet.aux1 = (digitalRead(PIN_SW_ARM) == LOW) ? 1 : 0;   // ARM Switch
        tx_packet.aux2 = (digitalRead(PIN_SW_MODE) == LOW) ? 1 : 0;  // 0: Acro, 1: Stabilize
        tx_packet.aux3 = 0;
        tx_packet.aux4 = (digitalRead(PIN_SW_KILL) == LOW) ? 1 : 0;  // Emergency Kill

        tx_packet.packet_seq = seq_counter++;

        // Compute CRC16
        tx_packet.checksum = calculateCrc16((const uint8_t *)&tx_packet, sizeof(RadioControlPacket) - sizeof(uint16_t));

        // Transmit packet & check for ACK payload containing drone telemetry
        if (tx_radio.write(&tx_packet, sizeof(RadioControlPacket))) {
            if (tx_radio.isAckPayloadAvailable()) {
                tx_radio.read(&rx_telemetry, sizeof(RadioTelemetryPacket));
                telemetry_received = true;
            }
        }
    }

    // Print Telemetry HUD to Serial Monitor at 5Hz
    if (now - last_telem_print >= 200) {
        last_telem_print = now;

        if (telemetry_received) {
            float roll  = (float)rx_telemetry.roll_deg_x10 / 10.0f;
            float pitch = (float)rx_telemetry.pitch_deg_x10 / 10.0f;
            float yaw   = (float)rx_telemetry.yaw_deg_x10 / 10.0f;
            float alt_m = (float)rx_telemetry.altitude_cm / 100.0f;
            float vbat  = (float)rx_telemetry.vbat_mv / 1000.0f;

            const char *state_str = "DISARMED";
            if (rx_telemetry.flight_state == 2) state_str = "ARMED";
            else if (rx_telemetry.flight_state == 3) state_str = "FAILSAFE";
            else if (rx_telemetry.flight_state == 4) state_str = "EMERGENCY";

            const char *mode_str = "ACRO";
            if (rx_telemetry.flight_mode == 1) mode_str = "STABILIZE";
            else if (rx_telemetry.flight_mode == 2) mode_str = "ALT_HOLD";

            Serial.printf("[TELEMETRY] State: %-9s | Mode: %-9s | Bat: %5.2fV | Alt: %5.2fm | Roll: %5.1f° | Pitch: %5.1f° | Yaw: %5.1f° | Link: %3d%%\n",
                          state_str, mode_str, vbat, alt_m, roll, pitch, yaw, rx_telemetry.rssi_quality);
        } else {
            Serial.println("[TX] Searching for drone telemetry connection...");
        }
    }
}
