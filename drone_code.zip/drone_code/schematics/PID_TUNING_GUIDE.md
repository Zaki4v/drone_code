# ESP32-S3 Drone PID Tuning & Operational Procedures

## 1. ESC Calibration Procedure (Throttle Endpoint Alignment)
All 40A ESCs must have identical pulse endpoints (1000µs = OFF, 2000µs = FULL).

1. **REMOVE ALL PROPELLERS** from the motors.
2. Hold down the **BOOT button (GPIO 0)** on the ESP32-S3 while plugging in the USB/power.
3. The firmware enters `motors.runCalibrationSequence()`:
   - Sets all motor outputs to `2000µs` (Max Throttle).
   - Prompt: **"Connect LiPo Battery NOW!"**
4. Connect the 3S LiPo battery within 4 seconds.
5. The ESCs emit confirmation beeps acknowledging high throttle.
6. The firmware drops the pulse to `1000µs` (Low Throttle).
7. The ESCs emit 3 descending beeps followed by 1 long confirmation beep.
8. Unplug the LiPo and reboot the ESP32-S3. Calibration is now permanently stored in the ESCs.

---

## 2. Sensor & IMU Calibration
1. Place the quadcopter on a completely level, vibration-free surface.
2. Power on the drone.
3. The firmware automatically samples 1000 data points to calculate:
   - Gyroscope zero-bias drift: $gx_{bias}, gy_{bias}, gz_{bias}$
   - Accelerometer level trim: $ax_{bias}, ay_{bias}, az_{bias}$
4. Calibration is saved to ESP32-S3 NVS flash (`drone_calib` namespace) and reloaded automatically on subsequent boots.

---

## 3. Arming & Disarming Sequence

### Safety Interlocks:
The drone will **ONLY ARM** if ALL of the following criteria are met:
1. **Radio Link Alive**: Transmitting active packets (failsafe inactive).
2. **Throttle at Zero**: Throttle stick < `1060µs`.
3. **Drone is Level**: Roll and Pitch within `±25°`.
4. **Kill Switch Inactive**: AUX4 switch is OFF.

### Arming Gestures:
- **ARM**: Flip **AUX1 switch to 1** OR hold **Throttle LOW + Yaw RIGHT** for 0.5s.
  - *Feedback*: Buzzer emits a single solid confirmation tone; Status LED turns solid ON; Motors spin at idle (`1120µs`).
- **DISARM**: Flip **AUX1 switch to 0** OR hold **Throttle LOW + Yaw LEFT** for 0.25s.
  - *Feedback*: Buzzer emits 2 short beeps; Status LED blinks slowly; Motors shut off (`1000µs`).
- **EMERGENCY KILL**: Flip **AUX4 switch** -> Instant motor cutoff regardless of flight state.

---

## 4. PID Tuning Procedure for A2212 1400KV Motors (3S LiPo)

The flight controller uses a **Cascaded Dual-Loop Controller**:
- **Outer Loop**: Angle / Attitude Controller (Roll & Pitch auto-leveling).
- **Inner Loop**: Angular Velocity / Rate Controller (Roll, Pitch, Yaw gyroscopic damping).

### Default Baseline Values:
```cpp
// Outer Loop (Angle Mode)
#define PID_ROLL_ANGLE_KP    4.5f
#define PID_PITCH_ANGLE_KP   4.5f

// Inner Loop (Rate Mode)
#define PID_ROLL_RATE_KP     1.25f
#define PID_ROLL_RATE_KI     1.80f
#define PID_ROLL_RATE_KD     0.038f

#define PID_PITCH_RATE_KP    1.25f
#define PID_PITCH_RATE_KI    1.80f
#define PID_PITCH_RATE_KD    0.038f

#define PID_YAW_RATE_KP      2.80f
#define PID_YAW_RATE_KI      2.10f
#define PID_YAW_RATE_KD      0.005f
```

### Step-by-Step Tuning Protocol:

#### Step 1: Tune Inner Loop Rate $K_p$ (Roll & Pitch)
- Set $K_i = 0$ and $K_d = 0$.
- In Rate/Acro mode (AUX2 = 0), slowly increase $K_p$ until the drone exhibits high-frequency oscillations (buzzing/wobble) upon rapid stick movements.
- Reduce $K_p$ by 30% from the oscillation threshold.

#### Step 2: Tune Inner Loop Rate $K_d$ (Damping)
- Increase $K_d$ gradually to eliminate residual overshoot and bounce-back when releasing the sticks.
- *Warning*: Setting $K_d$ too high causes high-frequency motor heating due to amplification of mechanical noise. Check motor temperature after 30 seconds of hover. If motors are warm/hot to the touch, decrease $K_d$ and verify MPU6050 vibration isolation.

#### Step 3: Tune Inner Loop Rate $K_i$ (Wind & Steady-State Rejection)
- Increase $K_i$ until the drone holds its commanded attitude in forward flight without nose-drop or drifting in ambient breeze.

#### Step 4: Tune Outer Loop Angle $K_p$ (Auto-Leveling Response)
- Switch to Stabilize Mode (AUX2 = 1).
- Increase `PID_ROLL_ANGLE_KP` and `PID_PITCH_ANGLE_KP` until self-leveling is crisp and authoritative without sluggishness or slow wobbling.
