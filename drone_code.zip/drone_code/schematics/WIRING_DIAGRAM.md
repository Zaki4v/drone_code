# ESP32-S3 Drone Hardware & Wiring Guide

## 1. System Overview
- **Flight Controller MCU**: ESP32-S3 (Dual-Core Xtensa LX7 @ 240MHz)
- **Motors**: 4x A2212 1400KV Brushless Outrunner Motors
- **ESCs**: 4x 40A Brushless ESCs (50Hz - 400Hz PWM)
- **Radio Link**: nRF24L01+ with PA (Power Amplifier) + LNA (Low Noise Amplifier) & SMA Antenna
- **IMU**: MPU6050 (6-Axis Gyroscope & Accelerometer with DLPF)
- **Barometer & Environment**: BMP280 (High-precision barometric altimeter) + AHT20 (Humidity & Temperature)
- **Battery**: 3S LiPo Battery (11.1V Nominal, 12.6V Fully Charged, 2200mAh - 3300mAh, 25C+)

---

## 2. Pin Mapping Table (ESP32-S3)

| Component | Pin Function | ESP32-S3 GPIO | Notes |
| :--- | :--- | :--- | :--- |
| **I2C Bus** | SDA (Data) | **GPIO 8** | Shared by MPU6050, BMP280, AHT20 (4.7kΩ Pull-up to 3.3V) |
| | SCL (Clock) | **GPIO 9** | Shared by MPU6050, BMP280, AHT20 (4.7kΩ Pull-up to 3.3V) |
| **nRF24L01+ PA/LNA** | CE (Chip Enable) | **GPIO 10** | High-speed RF control |
| | CSN (SPI Chip Select)| **GPIO 14** | SPI Select |
| | SCK (SPI Clock) | **GPIO 12** | Hardware FSPI Clock |
| | MISO (SPI Data In) | **GPIO 13** | Hardware FSPI MISO |
| | MOSI (SPI Data Out)| **GPIO 11** | Hardware FSPI MOSI |
| | IRQ (Optional) | **GPIO 21** | Hardware Interrupt |
| **ESC Motor 1** | PWM Signal (FR, CCW)| **GPIO 15** | Front-Right Motor (Counter-Clockwise) |
| **ESC Motor 2** | PWM Signal (RR, CW) | **GPIO 16** | Rear-Right Motor (Clockwise) |
| **ESC Motor 3** | PWM Signal (RL, CCW)| **GPIO 17** | Rear-Left Motor (Counter-Clockwise) |
| **ESC Motor 4** | PWM Signal (FL, CW) | **GPIO 18** | Front-Left Motor (Clockwise) |
| **Battery Voltage**| ADC Input | **GPIO 1** | Voltage Divider (100kΩ / 10kΩ) to LiPo (+) |
| **Buzzer** | Active Buzzer (+) | **GPIO 6** | Low battery & state buzzer |
| **Status LED** | External LED (+) | **GPIO 7** | Armed / Failsafe indicator (with 330Ω resistor) |

---

## 3. Quad-X Motor Geometry & Rotation

```
             FRONT
      (M4 CW)     (M1 CCW)
         \           /
          \   [X]   /
           \       /
            \     /
           /       \
          /   [X]   \
         /           \
      (M3 CCW)    (M2 CW)
              REAR
```

### Motor Rotation & Propeller Configuration:
- **Motor 1 (Front-Right)**: Spins **Counter-Clockwise (CCW)** -> Uses standard CCW (Push) Propeller.
- **Motor 2 (Rear-Right)**: Spins **Clockwise (CW)** -> Uses CW (Reverse / Pull) Propeller.
- **Motor 3 (Rear-Left)**: Spins **Counter-Clockwise (CCW)** -> Uses standard CCW (Push) Propeller.
- **Motor 4 (Front-Left)**: Spins **Clockwise (CW)** -> Uses CW (Reverse / Pull) Propeller.

> **Tip for reversing motor rotation**: Swap any two of the three 3.5mm bullet connector wires between the ESC and the motor.

---

## 4. Power Architecture & Decoupling

```
 [ 3S LiPo Battery: 11.1V - 12.6V ]
        |
        +-----------------------------------> [ Power Distribution Board (PDB) ]
        |                                                |
        |                                                +---> ESC 1 (40A) -> Motor 1 (A2212 1400KV)
        |                                                +---> ESC 2 (40A) -> Motor 2 (A2212 1400KV)
        |                                                +---> ESC 3 (40A) -> Motor 3 (A2212 1400KV)
        |                                                +---> ESC 4 (40A) -> Motor 4 (A2212 1400KV)
        |
        +---> [ Voltage Divider: 100kΩ / 10kΩ ] ------> ESP32-S3 GPIO 1 (Battery Monitor)
        |
        +---> [ 5V / 3A BEC or Buck Regulator ]
                    |
                    +---> ESP32-S3 (5V / VBUS Pin)
                    |
                    +---> [ High-Current 3.3V LDO / AMS1117-3.3 ]
                                |
                                +---> nRF24L01+ PA/LNA (VCC)
                                |       |
                                |       +-- [ 100µF Low-ESR Electrolytic + 100nF Ceramic Cap ] -- GND
                                |
                                +---> MPU6050 (VCC: 3.3V)
                                +---> BMP280 + AHT20 (VCC: 3.3V)
```

### Critical Hardware Precautions:
1. **nRF24L01+ PA/LNA Power Supply**: The amplified nRF24 module draws up to **150mA - 200mA peak pulses during transmission**. Powering it directly from weak 3.3V onboard MCU pins causes brownouts. **Solder a 10µF to 100µF capacitor directly across the VCC and GND pins of the nRF24 module!**
2. **Common Ground**: All grounds (LiPo GND, ESC Signal GND, ESP32-S3 GND, Sensor GND, Radio GND) MUST be tied to a single common Ground Plane.
3. **Vibration Damping**: Mount the MPU6050 sensor board using 3M double-sided foam tape or soft silicone anti-vibration standoffs. This reduces acoustic motor noise above 200Hz.
4. **Propeller Selection for A2212 1400KV on 3S LiPo**:
   - **Recommended Propellers**: 8045 (8x4.5 inch) or 7045 (7x4.5 inch) 2-blade propellers.
   - *Note*: Avoid 1045 props with 1400KV motors on 3S, as they draw excessive current (>25A per motor) and cause overheating. 8045 gives ~800g thrust per motor (~3.2kg total max thrust) at high efficiency.
